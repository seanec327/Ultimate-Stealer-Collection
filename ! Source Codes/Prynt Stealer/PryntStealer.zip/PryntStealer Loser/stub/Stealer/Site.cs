﻿using System;

namespace Stealer
{
	// Token: 0x0200000E RID: 14
	internal struct Site
	{
		// Token: 0x1700000F RID: 15
		// (get) Token: 0x0600003B RID: 59 RVA: 0x00002B12 File Offset: 0x00000D12
		// (set) Token: 0x0600003C RID: 60 RVA: 0x00002B1A File Offset: 0x00000D1A
		public string sUrl { get; set; }

		// Token: 0x17000010 RID: 16
		// (get) Token: 0x0600003D RID: 61 RVA: 0x00002B23 File Offset: 0x00000D23
		// (set) Token: 0x0600003E RID: 62 RVA: 0x00002B2B File Offset: 0x00000D2B
		public string sTitle { get; set; }

		// Token: 0x17000011 RID: 17
		// (get) Token: 0x0600003F RID: 63 RVA: 0x00002B34 File Offset: 0x00000D34
		// (set) Token: 0x06000040 RID: 64 RVA: 0x00002B3C File Offset: 0x00000D3C
		public int iCount { get; set; }
	}
}
