﻿using System;

namespace Stealer
{
	// Token: 0x0200000F RID: 15
	internal struct Bookmark
	{
		// Token: 0x17000012 RID: 18
		// (get) Token: 0x06000041 RID: 65 RVA: 0x00002B45 File Offset: 0x00000D45
		// (set) Token: 0x06000042 RID: 66 RVA: 0x00002B4D File Offset: 0x00000D4D
		public string sUrl { get; set; }

		// Token: 0x17000013 RID: 19
		// (get) Token: 0x06000043 RID: 67 RVA: 0x00002B56 File Offset: 0x00000D56
		// (set) Token: 0x06000044 RID: 68 RVA: 0x00002B5E File Offset: 0x00000D5E
		public string sTitle { get; set; }
	}
}
