﻿using System;
using System.Text.RegularExpressions;

namespace Stealer.Chromium
{
	// Token: 0x02000047 RID: 71
	internal sealed class Parser
	{
		// Token: 0x060000FF RID: 255 RVA: 0x00008488 File Offset: 0x00006688
		public static string RemoveLatest(string data)
		{
			return Regex.Split(Regex.Split(data, "\",")[0], "\"")[0];
		}

		// Token: 0x06000100 RID: 256 RVA: 0x000084A3 File Offset: 0x000066A3
		public static bool DetectTitle(string data)
		{
			return data.Contains("\"name");
		}

		// Token: 0x06000101 RID: 257 RVA: 0x000084B0 File Offset: 0x000066B0
		public static string Get(string data, int index)
		{
			string result;
			try
			{
				result = Parser.RemoveLatest(Regex.Split(data, Parser.separator)[index]);
			}
			catch (IndexOutOfRangeException)
			{
				result = "Failed to parse url";
			}
			return result;
		}

		// Token: 0x040000B3 RID: 179
		public static string separator = "\": \"";
	}
}
