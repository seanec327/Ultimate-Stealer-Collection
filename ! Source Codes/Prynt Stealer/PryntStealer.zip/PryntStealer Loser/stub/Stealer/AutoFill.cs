﻿using System;

namespace Stealer
{
	// Token: 0x0200000D RID: 13
	internal struct AutoFill
	{
		// Token: 0x04000033 RID: 51
		public string sName;

		// Token: 0x04000034 RID: 52
		public string sValue;
	}
}
