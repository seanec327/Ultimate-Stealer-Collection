﻿using System;

namespace Stealer
{
	// Token: 0x0200000B RID: 11
	internal struct Cookie
	{
		// Token: 0x17000004 RID: 4
		// (get) Token: 0x06000025 RID: 37 RVA: 0x00002A57 File Offset: 0x00000C57
		// (set) Token: 0x06000026 RID: 38 RVA: 0x00002A5F File Offset: 0x00000C5F
		public string sHostKey { get; set; }

		// Token: 0x17000005 RID: 5
		// (get) Token: 0x06000027 RID: 39 RVA: 0x00002A68 File Offset: 0x00000C68
		// (set) Token: 0x06000028 RID: 40 RVA: 0x00002A70 File Offset: 0x00000C70
		public string sName { get; set; }

		// Token: 0x17000006 RID: 6
		// (get) Token: 0x06000029 RID: 41 RVA: 0x00002A79 File Offset: 0x00000C79
		// (set) Token: 0x0600002A RID: 42 RVA: 0x00002A81 File Offset: 0x00000C81
		public string sPath { get; set; }

		// Token: 0x17000007 RID: 7
		// (get) Token: 0x0600002B RID: 43 RVA: 0x00002A8A File Offset: 0x00000C8A
		// (set) Token: 0x0600002C RID: 44 RVA: 0x00002A92 File Offset: 0x00000C92
		public string sExpiresUtc { get; set; }

		// Token: 0x17000008 RID: 8
		// (get) Token: 0x0600002D RID: 45 RVA: 0x00002A9B File Offset: 0x00000C9B
		// (set) Token: 0x0600002E RID: 46 RVA: 0x00002AA3 File Offset: 0x00000CA3
		public string sKey { get; set; }

		// Token: 0x17000009 RID: 9
		// (get) Token: 0x0600002F RID: 47 RVA: 0x00002AAC File Offset: 0x00000CAC
		// (set) Token: 0x06000030 RID: 48 RVA: 0x00002AB4 File Offset: 0x00000CB4
		public string sValue { get; set; }

		// Token: 0x1700000A RID: 10
		// (get) Token: 0x06000031 RID: 49 RVA: 0x00002ABD File Offset: 0x00000CBD
		// (set) Token: 0x06000032 RID: 50 RVA: 0x00002AC5 File Offset: 0x00000CC5
		public string sIsSecure { get; set; }
	}
}
