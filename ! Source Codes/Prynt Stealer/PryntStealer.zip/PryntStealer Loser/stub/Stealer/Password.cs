﻿using System;

namespace Stealer
{
	// Token: 0x0200000A RID: 10
	public struct Password
	{
		// Token: 0x17000001 RID: 1
		// (get) Token: 0x0600001F RID: 31 RVA: 0x00002A24 File Offset: 0x00000C24
		// (set) Token: 0x06000020 RID: 32 RVA: 0x00002A2C File Offset: 0x00000C2C
		public string sUrl { get; set; }

		// Token: 0x17000002 RID: 2
		// (get) Token: 0x06000021 RID: 33 RVA: 0x00002A35 File Offset: 0x00000C35
		// (set) Token: 0x06000022 RID: 34 RVA: 0x00002A3D File Offset: 0x00000C3D
		public string sUsername { get; set; }

		// Token: 0x17000003 RID: 3
		// (get) Token: 0x06000023 RID: 35 RVA: 0x00002A46 File Offset: 0x00000C46
		// (set) Token: 0x06000024 RID: 36 RVA: 0x00002A4E File Offset: 0x00000C4E
		public string sPassword { get; set; }
	}
}
