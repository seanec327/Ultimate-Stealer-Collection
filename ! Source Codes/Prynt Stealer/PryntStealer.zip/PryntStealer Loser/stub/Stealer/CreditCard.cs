﻿using System;

namespace Stealer
{
	// Token: 0x0200000C RID: 12
	internal struct CreditCard
	{
		// Token: 0x1700000B RID: 11
		// (get) Token: 0x06000033 RID: 51 RVA: 0x00002ACE File Offset: 0x00000CCE
		// (set) Token: 0x06000034 RID: 52 RVA: 0x00002AD6 File Offset: 0x00000CD6
		public string sNumber { get; set; }

		// Token: 0x1700000C RID: 12
		// (get) Token: 0x06000035 RID: 53 RVA: 0x00002ADF File Offset: 0x00000CDF
		// (set) Token: 0x06000036 RID: 54 RVA: 0x00002AE7 File Offset: 0x00000CE7
		public string sExpYear { get; set; }

		// Token: 0x1700000D RID: 13
		// (get) Token: 0x06000037 RID: 55 RVA: 0x00002AF0 File Offset: 0x00000CF0
		// (set) Token: 0x06000038 RID: 56 RVA: 0x00002AF8 File Offset: 0x00000CF8
		public string sExpMonth { get; set; }

		// Token: 0x1700000E RID: 14
		// (get) Token: 0x06000039 RID: 57 RVA: 0x00002B01 File Offset: 0x00000D01
		// (set) Token: 0x0600003A RID: 58 RVA: 0x00002B09 File Offset: 0x00000D09
		public string sName { get; set; }
	}
}
