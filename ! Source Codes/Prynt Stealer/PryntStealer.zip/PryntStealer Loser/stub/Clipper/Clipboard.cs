﻿using System;
using System.Threading;
using System.Windows.Forms;

namespace Clipper
{
	// Token: 0x02000050 RID: 80
	internal sealed class Clipboard
	{
		// Token: 0x0600012A RID: 298 RVA: 0x0000901C File Offset: 0x0000721C
		public static string GetText()
		{
			string ReturnValue = string.Empty;
			try
			{
				Thread thread = new Thread(delegate()
				{
					ReturnValue = Clipboard.GetText();
				});
				thread.SetApartmentState(ApartmentState.STA);
				thread.Start();
				thread.Join();
			}
			catch
			{
			}
			return ReturnValue;
		}

		// Token: 0x0600012B RID: 299 RVA: 0x00009078 File Offset: 0x00007278
		public static void SetText(string text)
		{
			Thread thread = new Thread(delegate()
			{
				try
				{
					Clipboard.SetText(text);
				}
				catch
				{
				}
			});
			thread.SetApartmentState(ApartmentState.STA);
			thread.Start();
			thread.Join();
		}
	}
}
