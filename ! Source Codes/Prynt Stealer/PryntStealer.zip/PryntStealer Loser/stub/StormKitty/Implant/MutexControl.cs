﻿using System;
using System.Threading;

namespace StormKitty.Implant
{
	// Token: 0x0200006D RID: 109
	internal sealed class MutexControl
	{
		// Token: 0x060001B3 RID: 435 RVA: 0x0000D6D4 File Offset: 0x0000B8D4
		public static void Check()
		{
			bool flag = false;
			new Mutex(false, Config.Mutex, ref flag);
			if (!flag)
			{
				Environment.Exit(1);
			}
		}
	}
}
