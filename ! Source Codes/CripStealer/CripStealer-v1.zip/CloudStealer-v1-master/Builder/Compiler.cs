using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using Microsoft.CodeAnalysis;
using Microsoft.CodeAnalysis.CSharp;

namespace BuilderV6
{
    public static class Compiler
    {
        public static bool Compile(string outputPath, Dictionary<string, string> sourceFiles, bool isExe = true)
        {
            var syntaxTrees = sourceFiles.Select(kv =>
                CSharpSyntaxTree.ParseText(kv.Value, path: kv.Key)).ToList();

            var refs = new List<MetadataReference>
            {
                MetadataReference.CreateFromFile(typeof(object).Assembly.Location),
                MetadataReference.CreateFromFile(typeof(Console).Assembly.Location),
            };

            string? tpa = AppContext.GetData("TRUSTED_PLATFORM_ASSEMBLIES") as string;
            if (!string.IsNullOrEmpty(tpa))
            {
                foreach (var asmPath in tpa.Split(';', StringSplitOptions.RemoveEmptyEntries))
                {
                    try
                    {
                        if (File.Exists(asmPath))
                            refs.Add(MetadataReference.CreateFromFile(asmPath));
                    }
                    catch { }
                }
            }

            string[] refAssemblies = {
                "System.Core", "System.Net.Http", "System.IO.Compression",
                "System.Security", "System.Xml", "Microsoft.Win32.Registry",
                "System.Linq", "System.Collections.Concurrent",
                "System.Runtime.InteropServices", "System.Threading.Tasks",
                "System.Security.Cryptography.ProtectedData", "System.Net.Sockets",
                "System.Net.Primitives", "System.IO.FileSystem",
                "System.Runtime", "System.Text.Encoding", "System.Diagnostics.Process",
                "System.Security.Cryptography", "System.Text.RegularExpressions",
                "System.Private.Uri", "System.Diagnostics",
            };

            foreach (var asmName in refAssemblies)
            {
                try
                {
                    var asm = Assembly.Load(asmName);
                    if (asm != null && !string.IsNullOrEmpty(asm.Location))
                        refs.Add(MetadataReference.CreateFromFile(asm.Location));
                }
                catch { }
            }

            var options = new CSharpCompilationOptions(
                outputKind: isExe ? OutputKind.ConsoleApplication : OutputKind.DynamicallyLinkedLibrary,
                optimizationLevel: OptimizationLevel.Release,
                platform: Platform.AnyCpu,
                allowUnsafe: false)
                .WithConcurrentBuild(true);

            var compilation = CSharpCompilation.Create(
                Path.GetFileNameWithoutExtension(outputPath),
                syntaxTrees, refs, options);

            using (var ms = new FileStream(outputPath, FileMode.Create))
            {
                var result = compilation.Emit(ms);
                if (!result.Success)
                {
                    foreach (var diag in result.Diagnostics.Where(d => d.Severity == DiagnosticSeverity.Error))
                        Console.Error.WriteLine($"  ERROR [{diag.Location.SourceTree?.FilePath}]: {diag.GetMessage()}");
                    return false;
                }
            }

            // Emit runtimeconfig.json for framework-dependent EXEs
            string tfm = "net9.0";
            try
            {
                var asm = System.Reflection.Assembly.Load("System.Runtime");
                var ver = asm?.GetName()?.Version;
                if (ver != null) tfm = $"net{ver.Major}.{ver.Minor}";
            }
            catch { }
            string rtcPath = Path.ChangeExtension(outputPath, null) + ".runtimeconfig.json";
            string rtcJson = $@"{{
  ""runtimeOptions"": {{
    ""tfm"": ""{tfm}"",
    ""framework"": {{
      ""name"": ""Microsoft.NETCore.App"",
      ""version"": ""{tfm.Replace("net", "")}.0""
    }}
  }}
}}";
            File.WriteAllText(rtcPath, rtcJson);

            return true;
        }
    }
}
