using System;
using System.Collections.Generic;
using System.IO;

namespace BuilderV6
{
    public static class TemplateLoader
    {
        public static Dictionary<string, string> LoadTemplates(string templateDir)
        {
            var templates = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
            string fullDir = Path.GetFullPath(templateDir);
            if (!Directory.Exists(fullDir))
                throw new DirectoryNotFoundException($"Template directory not found: {fullDir}");

            foreach (var file in Directory.GetFiles(fullDir, "*.tmpl", SearchOption.AllDirectories))
            {
                string key = file.Substring(fullDir.Length + 1)
                    .Replace("\\", "/")
                    .Replace(".cs.tmpl", "")
                    .Replace(".tmpl", "");
                templates[key] = File.ReadAllText(file);
                Console.WriteLine($"  [Template] {key}");
            }
            Console.WriteLine($"  Loaded {templates.Count} templates from {fullDir}");
            return templates;
        }
    }
}
