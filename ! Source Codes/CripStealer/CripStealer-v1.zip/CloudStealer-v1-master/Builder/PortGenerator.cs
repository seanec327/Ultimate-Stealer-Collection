using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.NetworkInformation;
using System.Security.Cryptography;

namespace BuilderV6
{
    public static class PortGenerator
    {
        static readonly int[] ExcludedRanges = new[] {
            1024, 3389, 5985, 5986, 8080, 8443, 8888, 9000, 9090, 30000
        };

        public static int[] GeneratePorts(int count = 3, int min = 40000, int max = 65000)
        {
            var rng = RandomNumberGenerator.Create();
            var ports = new HashSet<int>();
            var used = GetUsedPorts();

            while (ports.Count < count)
            {
                byte[] bytes = new byte[2];
                rng.GetBytes(bytes);
                int port = min + (BitConverter.ToUInt16(bytes, 0) % (max - min + 1));

                if (used.Contains(port)) continue;
                if (ExcludedRanges.Any(e => Math.Abs(port - e) < 100)) continue;
                ports.Add(port);
            }

            return ports.OrderBy(p => p).ToArray();
        }

        static HashSet<int> GetUsedPorts()
        {
            var set = new HashSet<int>();
            try
            {
                var props = IPGlobalProperties.GetIPGlobalProperties();
                foreach (var ep in props.GetActiveTcpListeners()) set.Add(ep.Port);
                foreach (var ep in props.GetActiveUdpListeners()) set.Add(ep.Port);
            }
            catch { }
            return set;
        }
    }
}
