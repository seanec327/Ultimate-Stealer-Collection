using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using Microsoft.CodeAnalysis;
using Microsoft.CodeAnalysis.CSharp;
using Microsoft.CodeAnalysis.CSharp.Syntax;

namespace BuilderV6.Polymorphism
{
    public static class StringEncryptor
    {
        public sealed class StringKeyPair
        {
            public byte[] Key { get; set; } = Array.Empty<byte>();
            public byte[] IV { get; set; } = Array.Empty<byte>();
        }

        public static StringKeyPair GenerateKey()
        {
            var key = new byte[32];
            var iv = new byte[16];
            using (var rng = RandomNumberGenerator.Create())
            {
                rng.GetBytes(key);
                rng.GetBytes(iv);
            }
            return new StringKeyPair { Key = key, IV = iv };
        }

        public static string Transform(string source, byte[] key, byte[] iv, string classPrefix)
        {
            var tree = CSharpSyntaxTree.ParseText(source);
            var root = tree.GetRoot();

            var literals = root.DescendantNodes()
                .OfType<LiteralExpressionSyntax>()
                .Where(l => l.IsKind(SyntaxKind.StringLiteralExpression))
                .ToList();

            var replacements = new List<(int start, int length, string text)>();

            foreach (var literal in literals)
            {
                string tokenText = literal.Token.Text;
                if (tokenText.StartsWith("@"))
                    continue;

                string value = literal.Token.ValueText;
                if (value.Length < 5)
                    continue;

                if (literal.Ancestors().Any(a => a is AttributeSyntax))
                    continue;

                if (value.Contains("\\"))
                    continue;
                if (value.Contains("/"))
                    continue;
                if (value.All(c => char.IsLower(c) || c == '.' || c == '_'))
                    continue;
                if (value.Contains("-") || value.StartsWith("{"))
                    continue;

                byte[] plain = Encoding.UTF8.GetBytes(value);
                byte[] cipher;
                using (var aes = Aes.Create())
                {
                    aes.Key = key;
                    aes.IV = iv;
                    aes.Mode = CipherMode.CBC;
                    aes.Padding = PaddingMode.PKCS7;
                    using (var enc = aes.CreateEncryptor())
                        cipher = enc.TransformFinalBlock(plain, 0, plain.Length);
                }

                string b64 = Convert.ToBase64String(cipher);
                string replacement = classPrefix + "Strings.Dec(\"" + b64 + "\")";
                replacements.Add((literal.Span.Start, literal.Span.Length, replacement));
            }

            var sb = new StringBuilder(source);
            foreach (var (start, length, text) in replacements.OrderByDescending(r => r.start))
            {
                sb.Remove(start, length);
                sb.Insert(start, text);
            }

            return sb.ToString();
        }

        public static string GenerateDecryptionClass(string classPrefix, byte[] key, byte[] iv)
        {
            string keyB64 = Convert.ToBase64String(key);
            string ivB64 = Convert.ToBase64String(iv);

            return "using System;\n" +
                   "using System.Security.Cryptography;\n" +
                   "using System.Text;\n\n" +
                   "    internal static class " + classPrefix + "Strings\n" +
                   "    {\n" +
                   "        static readonly byte[] _k = Convert.FromBase64String(\"" + keyB64 + "\");\n" +
                   "        static readonly byte[] _i = Convert.FromBase64String(\"" + ivB64 + "\");\n\n" +
                   "        internal static string Dec(string b64)\n" +
                   "        {\n" +
                   "            byte[] c = Convert.FromBase64String(b64);\n" +
                   "            using (var a = Aes.Create())\n" +
                   "            {\n" +
                   "                a.Key = _k; a.IV = _i; a.Mode = CipherMode.CBC; a.Padding = PaddingMode.PKCS7;\n" +
                   "                using (var d = a.CreateDecryptor())\n" +
                   "                {\n" +
                   "                    byte[] p = d.TransformFinalBlock(c, 0, c.Length);\n" +
                   "                    string s = Encoding.UTF8.GetString(p);\n" +
                   "                    Array.Clear(p, 0, p.Length);\n" +
                   "                    return s;\n" +
                   "                }\n" +
                   "            }\n" +
                   "        }\n" +
                   "    }\n";
        }
    }
}
