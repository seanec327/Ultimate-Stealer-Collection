using System;

namespace BuilderV6
{
    public class BuildConfig
    {
        public string ServerIp { get; set; } = "";
        public int[] ServerPorts { get; set; } = Array.Empty<int>();
        public int Tier { get; set; } = 1;
        public string BuildId { get; set; } = "";
        public string OutputDir { get; set; } = "./build";
        public string TemplateDir { get; set; } = "./Templates";
        public bool Stealth { get; set; }
        public bool Persist { get; set; }
    }
}
