using System;
using System.Security.Cryptography;
using System.Text;

namespace BuilderV6
{
    public static class BuildIdGenerator
    {
        public static string Generate(int length = 16)
        {
            const string chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
            var sb = new StringBuilder(length);
            byte[] rnd = new byte[length];
            using (var rng = RandomNumberGenerator.Create())
                rng.GetBytes(rnd);
            for (int i = 0; i < length; i++)
                sb.Append(chars[rnd[i] % chars.Length]);
            return sb.ToString();
        }
    }
}
